# 🔗 Protocols Guide - MacCommander Pro PROFESSIONAL

**Detailed information about supported protocols**

---

## SFTP (SSH File Transfer Protocol)

### Overview
- **Port:** 22 (default)
- **Security:** ✅ Encrypted
- **Authentication:** Password or SSH key
- **Best for:** Linux/Unix servers, secure transfers

### Features
- ✅ Full encryption
- ✅ SSH key support
- ✅ Reliable transfers
- ✅ Resume support
- ✅ Permissions preserved

### Configuration

```python
Profile Settings:
- Protocol: SFTP
- Host: server.example.com
- Port: 22
- Username: your_username
- Password: (optional)
- SSH Key: ~/.ssh/id_rsa (optional)
```

### SSH Key Setup

**Generate key:**
```bash
ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
```

**Copy to server:**
```bash
ssh-copy-id username@server.com
```

### Performance Tips
- Use compression for slow connections
- SSH keys are faster than passwords
- Keep-alive prevents timeouts

---

## FTP/FTPS (File Transfer Protocol)

### Overview
- **FTP Port:** 21
- **FTPS Port:** 990
- **Security:** FTP ❌ / FTPS ✅
- **Best for:** Legacy systems, web hosting

### FTP vs. FTPS

**FTP (Insecure):**
- No encryption
- Fast
- Simple
- ⚠️ Passwords in plaintext
- Use only on trusted networks

**FTPS (Secure):**
- SSL/TLS encryption
- Secure passwords
- Certificate validation
- Recommended for internet use

### Configuration

```python
FTP Profile:
- Protocol: FTP
- Port: 21
- SSL/TLS: ❌

FTPS Profile:
- Protocol: FTPS  
- Port: 990
- SSL/TLS: ✅
```

### Active vs. Passive Mode
- **Passive:** Default, works with firewalls
- **Active:** Legacy, may have firewall issues

---

## SMB/CIFS (Server Message Block)

### Overview
- **Port:** 445 (default)
- **Security:** ✅ Encrypted (SMB3+)
- **Best for:** Windows servers, NAS devices
- **Platform:** Universal (Windows, macOS, Linux)

### Features
- ✅ Native Windows integration
- ✅ File/printer sharing
- ✅ Active Directory support
- ✅ High performance
- ✅ Locking support

### Configuration

```python
Profile Settings:
- Protocol: SMB
- Host: server.company.local (or IP)
- Port: 445
- Share: ShareName
- Username: your_username
- Password: ••••••••
- Domain: WORKGROUP (optional)
```

### Share Names

**Windows:**
```cmd
net share
```

**macOS:**
```bash
smbutil view //server.local
```

**Common shares:**
- `C$` - C: drive (admin only)
- `Users` - User folders
- `Public` - Public folder
- Custom share names

### Versions
- **SMB1:** ⚠️ Insecure, deprecated
- **SMB2:** Better performance
- **SMB3:** ✅ Encrypted, recommended

### Performance
- Fastest for Windows-to-Windows
- Good for NAS devices
- Optimized for local networks

---

## WebDAV (Web-based Distributed Authoring and Versioning)

### Overview
- **HTTP Port:** 80
- **HTTPS Port:** 443
- **Security:** HTTP ❌ / HTTPS ✅
- **Best for:** Cloud storage, web servers

### Features
- ✅ HTTP-based
- ✅ Firewall friendly
- ✅ Cloud integration
- ✅ Versioning support
- ✅ Wide compatibility

### Configuration

```python
Profile Settings:
- Protocol: WebDAV
- Host: dav.example.com/path
- Port: 443
- Username: your_username
- Password: ••••••••
- SSL/TLS: ✅ (HTTPS)
```

### Cloud Providers

#### Nextcloud
```
URL: cloud.example.com/remote.php/dav/files/username
Port: 443
SSL: ✅
```

#### ownCloud
```
URL: cloud.example.com/remote.php/webdav
Port: 443
SSL: ✅
```

#### Box.com
```
URL: dav.box.com/dav
Port: 443
SSL: ✅
Username: email@example.com
```

#### Yandex Disk
```
URL: webdav.yandex.com
Port: 443
SSL: ✅
```

#### Koofr
```
URL: app.koofr.net/dav
Port: 443
SSL: ✅
```

### Authentication
- Basic Auth (username/password)
- Token-based auth
- OAuth (some providers)
- App-specific passwords

---

## Protocol Comparison

| Feature | SFTP | FTP | FTPS | SMB | WebDAV |
|---------|------|-----|------|-----|--------|
| **Encryption** | ✅ | ❌ | ✅ | ✅ (SMB3) | ✅ (HTTPS) |
| **Speed** | Medium | Fast | Medium | Fast | Medium |
| **Firewall** | Easy | Hard | Medium | Easy | Easy |
| **Resume** | ✅ | ✅ | ✅ | ✅ | Partial |
| **Permissions** | Full | Limited | Limited | Full | Limited |
| **Locking** | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Best for** | Linux | Legacy | Web | Windows | Cloud |

---

## Port Reference

| Protocol | Default Port | Alternative |
|----------|--------------|-------------|
| SFTP | 22 | Custom |
| SSH | 22 | Custom |
| FTP | 21 | Custom |
| FTPS | 990 | Custom |
| SMB | 445 | 139 (old) |
| WebDAV HTTP | 80 | Custom |
| WebDAV HTTPS | 443 | Custom |

---

## Security Recommendations

### Encryption Priority

1. ✅ **Always use:** SFTP, FTPS, HTTPS WebDAV, SMB3
2. ⚠️ **Avoid:** Plain FTP, HTTP WebDAV, SMB1
3. 🔒 **Bonus:** SSH keys, 2FA, VPN

### Best Practices

**SFTP:**
- Use SSH keys
- Disable password auth on server
- Use strong keys (4096-bit RSA)
- Rotate keys periodically

**FTPS:**
- Verify certificates
- Use strong cipher suites
- Enable certificate pinning

**SMB:**
- Disable SMB1
- Use SMB3 encryption
- Strong passwords
- Limit share access

**WebDAV:**
- Always use HTTPS
- App-specific passwords
- Enable 2FA on cloud provider
- Token-based auth when available

---

## Performance Tuning

### SFTP
```
Optimizations:
- Compression: On for slow links
- SSH key: Faster than password
- Keep-alive: Prevent timeout
- Parallel transfers: Use multiple connections
```

### FTP/FTPS
```
Optimizations:
- Passive mode: Better with firewalls
- Binary mode: Faster transfers
- No encryption: FTP faster (insecure!)
- Resume: Enable for large files
```

### SMB
```
Optimizations:
- SMB3: Fastest version
- Multichannel: Use multiple NICs
- Direct mode: Skip cache
- Large MTU: Jumbo frames
```

### WebDAV
```
Optimizations:
- HTTP/2: Enable if supported
- Compression: On for text files
- Chunked upload: For large files
- Caching: Enable local cache
```

---

## Troubleshooting by Protocol

### SFTP Issues

**Problem:** "Permission denied"
```bash
# Check SSH access
ssh username@server.com

# Check key permissions
chmod 600 ~/.ssh/id_rsa
chmod 644 ~/.ssh/id_rsa.pub
```

**Problem:** "Connection refused"
```bash
# Check SSH is running
sudo systemctl status ssh  # Linux
sudo launchctl list | grep ssh  # macOS
```

### FTP Issues

**Problem:** "Can't connect"
```bash
# Test manually
ftp server.com
# Or
telnet server.com 21
```

**Problem:** "Passive mode fails"
```
Solution: Switch to Active mode
Or: Configure firewall for passive ports (49152-65535)
```

### SMB Issues

**Problem:** "Access denied"
```bash
# List shares
smbutil view //server

# Check status
smbutil status //server/share
```

**Problem:** "Slow performance"
```
Solutions:
- Disable SMB signing
- Use SMB3
- Check network speed
- Disable antivirus scanning
```

### WebDAV Issues

**Problem:** "401 Unauthorized"
```
Solutions:
- Verify username/password
- Check URL path
- Use app-specific password
- Enable WebDAV on server
```

**Problem:** "Can't write files"
```
Solutions:
- Check server permissions
- Verify WebDAV write access
- Check disk quota
- Test in browser first
```

---

## Advanced Features

### Multi-Protocol Strategy

Use different protocols for different needs:

```
Development:
- SFTP → Code files (security)
- SMB → Media files (speed)
- WebDAV → Documentation (cloud)

Production:
- SFTP → Secure deployment
- FTPS → Legacy compatibility
- SMB → Windows integration
```

### Failover Setup

```python
Primary: SFTP
Fallback 1: FTPS
Fallback 2: WebDAV

If SFTP fails → Try FTPS
If FTPS fails → Try WebDAV
```

### Protocol Tunneling

**VPN:**
```
Local network protocols over internet
- SMB over VPN
- Unencrypted FTP over VPN
```

**SSH Tunnel:**
```bash
# Tunnel FTP through SSH
ssh -L 2121:localhost:21 server.com
# Connect to localhost:2121
```

---

## Summary

**Choose the right protocol:**

- 🔒 **Need security?** → SFTP or FTPS
- ⚡ **Need speed?** → SMB (local) or FTP (insecure)
- ☁️ **Need cloud?** → WebDAV
- 🪟 **Need Windows?** → SMB
- 🐧 **Need Linux?** → SFTP

**Key points:**
- Always use encryption
- Choose based on your network
- Consider performance vs. security
- Test before deploying
- Monitor connection stats

---

**More info:** See MOUNT_GUIDE.md for mounting details!
