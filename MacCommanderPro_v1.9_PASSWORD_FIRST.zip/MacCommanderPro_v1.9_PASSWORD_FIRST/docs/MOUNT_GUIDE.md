# 💾 Mount Guide - MacCommander Pro PROFESSIONAL

**Complete guide to mounting remote servers as macOS volumes**

---

## 📖 Table of Contents

1. [Overview](#overview)
2. [SFTP Mounting](#sftp-mounting)
3. [FTP Mounting](#ftp-mounting)
4. [SMB Mounting](#smb-mounting)
5. [WebDAV Mounting](#webdav-mounting)
6. [Mount Options](#mount-options)
7. [Troubleshooting](#troubleshooting)
8. [Advanced Usage](#advanced-usage)

---

## Overview

### What is Mounting?

**Mounting** makes a remote server appear as a local volume in macOS Finder.

**Benefits:**
- 🗂️ Browse files in Finder
- 🖱️ Drag & drop files
- 📝 Edit files with any app
- 🔍 Spotlight search support
- 💾 Seamless integration

### Supported Protocols

| Protocol | Description | Best For |
|----------|-------------|----------|
| **SFTP** | Secure FTP over SSH | Linux/Unix servers, secure transfers |
| **FTP** | File Transfer Protocol | Legacy systems, quick access |
| **SMB** | Windows network shares | Windows servers, NAS devices |
| **WebDAV** | Web-based file access | Cloud storage, web servers |

---

## SFTP Mounting

### Requirements

**macOS System:**
```bash
brew install macfuse
brew install gromgit/fuse/sshfs-mac
```

**⚠️ Important:** Reboot after installing macFUSE!

### Quick Mount

1. **Create Profile:**
   - Protocol: SFTP
   - Host: `your-server.com`
   - Port: `22`
   - Username: `your-username`
   - Password: (or SSH key)

2. **Connect:**
   - Click "Connect"
   - Wait for 🟢 Connected

3. **Mount:**
   - Click "Mount"
   - Volume appears in `/Volumes/SFTP_your-server`

### SSH Key Authentication

**Generate key:**
```bash
ssh-keygen -t rsa -b 4096
```

**Copy to server:**
```bash
ssh-copy-id user@server.com
```

**In profile:**
- SSH Key: `~/.ssh/id_rsa`
- Leave password empty

### Mount Options

```bash
# Default mount
/Volumes/SFTP_your-server

# Custom mount point
/Volumes/MyWorkServer

# Specific remote path
Remote Path: /home/user/projects
```

### Example: Development Server

```
Profile Name: Dev Server
Protocol: SFTP
Host: dev.example.com
Port: 22
Username: developer
SSH Key: ~/.ssh/dev_rsa
Auto-mount: ✅
Remote Path: /var/www/html
```

**Result:** Your web server appears as a local folder!

---

## FTP Mounting

### Requirements

FTP mounting uses Finder's native support (no extra software needed).

### Quick Mount

1. **Create Profile:**
   - Protocol: FTP or FTPS
   - Host: `ftp.example.com`
   - Port: `21` (FTP) or `990` (FTPS)
   - Username: `ftpuser`
   - Password: `•••••`
   - SSL/TLS: ✅ (for FTPS)

2. **Mount:**
   - Click "Mount"
   - Opens in Finder automatically

### FTP vs. FTPS

**FTP (Insecure):**
- Port 21
- No encryption
- Fast but not secure
- Use only on trusted networks

**FTPS (Secure):**
- Port 990
- SSL/TLS encryption
- Secure transmission
- Recommended for internet

### Example: Web Hosting

```
Profile Name: Website FTP
Protocol: FTPS
Host: ftp.myhosting.com
Port: 990
Username: webuser
Password: •••••
SSL/TLS: ✅
Remote Path: /public_html
```

---

## SMB Mounting

### Requirements

SMB is built into macOS - no additional software needed!

### Quick Mount

1. **Create Profile:**
   - Protocol: SMB
   - Host: `192.168.1.100` or `server.local`
   - Port: `445`
   - Share: `Documents` (share name)
   - Username: `windowsuser`
   - Password: `•••••`
   - Domain: `WORKGROUP` (optional)

2. **Mount:**
   - Click "Mount"
   - Share appears as `/Volumes/Documents`

### Finding Share Names

**On Windows:**
```cmd
net share
```

**On macOS:**
```bash
smbutil view //server.local
```

**Common shares:**
- `Users` - User folders
- `Public` - Public folder
- `Documents` - Shared documents
- Custom share names

### Example: Windows Server

```
Profile Name: Office Server
Protocol: SMB
Host: fileserver.company.local
Port: 445
Share: CompanyFiles
Username: john.doe
Password: •••••
Domain: COMPANY
```

### Example: NAS Device

```
Profile Name: My NAS
Protocol: SMB
Host: 192.168.1.50
Port: 445
Share: Backups
Username: admin
Password: •••••
Domain: (leave empty)
```

### Troubleshooting SMB

**Can't find server:**
- Use IP address instead of hostname
- Check firewall settings
- Verify SMB is enabled on server

**Access denied:**
- Verify username/password
- Check share permissions
- Try with/without domain

---

## WebDAV Mounting

### Requirements

WebDAV is built into macOS - no additional software needed!

### Quick Mount

1. **Create Profile:**
   - Protocol: WebDAV
   - Host: `dav.example.com/remote.php/dav/files/username`
   - Port: `443`
   - Username: `your-username`
   - Password: `•••••`
   - SSL/TLS: ✅

2. **Mount:**
   - Click "Mount"
   - Cloud storage appears in Finder!

### Cloud Providers

#### Nextcloud
```
Host: cloud.example.com/remote.php/dav/files/username
Port: 443
SSL/TLS: ✅
```

#### ownCloud
```
Host: cloud.example.com/remote.php/webdav
Port: 443
SSL/TLS: ✅
```

#### Box.com
```
Host: dav.box.com/dav
Port: 443
SSL/TLS: ✅
Username: your_email@example.com
```

#### Yandex Disk
```
Host: webdav.yandex.com
Port: 443
SSL/TLS: ✅
```

### Example: Nextcloud

```
Profile Name: My Cloud
Protocol: WebDAV
Host: cloud.mycompany.com/remote.php/dav/files/john
Port: 443
Username: john
Password: •••••
SSL/TLS: ✅
Auto-mount: ✅
```

**Result:** Your Nextcloud files in Finder!

---

## Mount Options

### Auto-Mount

Enable to mount automatically on connect:

```
Profile Settings:
✅ Auto-mount on connect
Mount Point: /Volumes/MyCloud
Remote Path: /Documents
```

**Benefits:**
- One-click access
- Consistent mount location
- Perfect for daily use

### Custom Mount Points

Instead of default paths like `/Volumes/SFTP_server`, use:

```
/Volumes/MyWork
/Volumes/ClientFiles
/Volumes/PersonalCloud
```

**How to set:**
1. Edit profile
2. Go to "Mount" tab
3. Set "Mount Point" field

### Remote Path Selection

Mount a specific directory instead of root:

```
SFTP Example:
Remote Path: /var/www/html

SMB Example:
Share: Documents
Remote Path: /Projects/CurrentYear

WebDAV Example:
Host: cloud.com/remote.php/dav/files/user
Remote Path: /Work/Active
```

---

## Troubleshooting

### General Issues

#### Mount Point Already Exists

**Problem:** "Volume already mounted"

**Solution:**
```bash
# Check what's mounted
mount | grep /Volumes

# Unmount manually
umount /Volumes/YourVolume

# Or use MacCommander's Unmount All
```

#### Permission Denied

**Problem:** Can't read/write files

**Solutions:**
- Check server permissions
- Verify username has access
- Try different user account
- Check file ownership on server

#### Slow Performance

**Problem:** Transfers are slow

**Solutions:**
- Check network speed
- Monitor latency in status widget
- Try different protocol (SFTP vs FTP)
- Check server load
- Use wired connection if possible

### Protocol-Specific Issues

#### SFTP: "SSHFS not available"

**Solution:**
```bash
# Install dependencies
brew install macfuse
brew install gromgit/fuse/sshfs-mac

# Reboot macOS
sudo reboot
```

#### SMB: "Connection failed"

**Solutions:**
```bash
# Test connection manually
smbutil status //server/share

# Check server is reachable
ping server.local

# Verify share exists
smbutil view //server
```

#### WebDAV: "401 Unauthorized"

**Solutions:**
- Verify username/password
- Check URL is complete
- Try HTTPS instead of HTTP
- Test in browser first
- Check app-specific password needed

### macOS-Specific Issues

#### macFUSE Not Loaded

**Problem:** "FUSE not loaded"

**Solution:**
```bash
# Check if loaded
kextstat | grep fuse

# Load manually
sudo /Library/Filesystems/macfuse.fs/Contents/Resources/load_macfuse

# Or reboot
```

#### Volume Not Appearing

**Problem:** Mount succeeds but no volume visible

**Solutions:**
- Check `/Volumes/` manually
- Restart Finder: `killall Finder`
- Check System Preferences → Security
- Verify mount point path

---

## Advanced Usage

### Multiple Mounts

Mount multiple servers simultaneously:

```
Active Mounts:
1. /Volumes/WorkServer (SFTP)
2. /Volumes/BackupNAS (SMB)
3. /Volumes/PersonalCloud (WebDAV)
```

Each mount:
- Independent connection
- Own status monitoring
- Separate statistics

### Persistent Mounts

For always-available access:

1. **Enable auto-mount** in profiles
2. **Add to Login Items:**
   - System Preferences → Users & Groups
   - Login Items → Add `maccommander_pro.py`

**Result:** Volumes mount automatically on login!

### Scripting

Mount from command line:

```bash
# Using osascript
osascript -e 'tell application "MacCommander Pro" to mount "My Server"'
```

### Mount in Background

```bash
# Silent mount
maccommander_pro.py --mount "Profile Name" --silent
```

### Unmount All on Logout

Add to logout script:
```bash
#!/bin/bash
# Unmount all MacCommander volumes
for vol in /Volumes/SFTP_* /Volumes/WebDAV_*; do
    [ -d "$vol" ] && umount "$vol"
done
```

---

## Best Practices

### Security

1. **Always use encryption:**
   - SFTP over FTP
   - FTPS over FTP
   - HTTPS WebDAV over HTTP
   - SMB with encryption

2. **Use SSH keys** when possible:
   - More secure than passwords
   - No password prompts
   - Can restrict access by key

3. **Strong passwords:**
   - Use unique passwords
   - Enable 2FA if available
   - Don't save passwords if shared computer

### Performance

1. **Choose right protocol:**
   - SFTP: Best security
   - SMB: Best for Windows/NAS
   - WebDAV: Best for cloud
   - FTP: Best speed (insecure)

2. **Network optimization:**
   - Use wired connection
   - Check latency first
   - Avoid VPN if possible
   - Use local network when available

3. **Monitor status:**
   - Watch connection uptime
   - Check transfer speeds
   - Monitor latency
   - React to slow connections

### Reliability

1. **Test before relying:**
   - Test connection first
   - Verify read/write access
   - Check stability over time

2. **Have backups:**
   - Multiple profiles for important servers
   - Different protocols as fallback
   - Local copies of critical files

3. **Regular maintenance:**
   - Update software
   - Renew SSH keys
   - Check server logs
   - Monitor disk space

---

## Examples

### Home Lab Setup

```
Profile: Lab Server
- Protocol: SFTP
- Host: 192.168.1.10
- Mount: /Volumes/HomeLab
- Auto-mount: ✅
- Purpose: Development environment
```

### Office Network

```
Profile: Office Files
- Protocol: SMB
- Host: fileserver.company.local
- Share: Shared
- Mount: /Volumes/OfficeFiles
- Auto-mount: ✅
- Purpose: Daily work files
```

### Cloud Backup

```
Profile: Cloud Backup
- Protocol: WebDAV
- Host: backup.mycloud.com/remote.php/dav/files/user
- Mount: /Volumes/CloudBackup
- Auto-mount: ✅
- Purpose: Automatic backups
```

### Client Work

```
Profile: Client FTP
- Protocol: FTPS
- Host: ftp.clientsite.com
- Mount: /Volumes/ClientSite
- Auto-mount: ❌ (on-demand)
- Purpose: Website updates
```

---

## Summary

**Mounting makes remote files feel local!**

- 🗂️ Browse in Finder
- 🖱️ Drag & drop
- 📝 Edit with any app
- 🔍 Search with Spotlight
- ✨ Seamless experience

**Choose the right protocol:**
- **SFTP** → Linux servers, secure
- **SMB** → Windows, NAS
- **WebDAV** → Cloud storage
- **FTP** → Legacy, fast (insecure)

**Follow best practices:**
- Use encryption
- Monitor performance
- Have fallback options
- Test before relying

---

**Happy mounting!** 🚀

For more help, see README.md or PROTOCOLS.md!
