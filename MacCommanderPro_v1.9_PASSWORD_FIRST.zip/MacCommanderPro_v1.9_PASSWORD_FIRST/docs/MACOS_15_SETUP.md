# Handbuch für macOS Startsicherheitsdienstprogramm (Apple Silicon Mac M4)

## Inhaltsverzeichnis
- Einführung
- Schritt 1: Mac in den Wiederherstellungsmodus starten
- Schritt 2: Benutzer auswählen und Menüleiste anzeigen
- Schritt 3: Auf das Startsicherheitsdienstprogramm zugreifen
- Schritt 4: Sicherheitseinstellungen anpassen
- Schritt 5: Neustart und Abschluss
- FAQs
- Support

---

## Einführung
Dieses Handbuch beschreibt die notwendigen Schritte, um die Sicherheitsrichtlinie des Startsicherheitsdienstprogramms auf einem Apple Silicon Mac (z. B. M4) anzupassen. Ziel ist es, die Installation und Verwaltung von Kernel-Erweiterungen (Systemerweiterungen) von verifizierten Entwicklern zu erlauben und so Drittanbieter-Software zu ermöglichen.

---

## Schritt 1: Mac in den Wiederherstellungsmodus starten
1. Mac ausschalten.
2. Power-Taste gedrückt halten, bis das Menü „Optionen“ erscheint.
3. Klicke auf **Optionen** und dann auf **Fortfahren**.

---

## Schritt 2: Benutzer auswählen und Menüleiste anzeigen
1. Wähle im Folgenden deinen macOS-Benutzeraccount aus (z. B. „kali“).
2. Gib dein Passwort ein und klicke auf **Weiter**.
3. Erst jetzt erscheint oben in der Fenstermitte die Menüleiste mit „Dienstprogramme“ und anderen Menüpunkten.

---

## Schritt 3: Auf das Startsicherheitsdienstprogramm zugreifen
1. Klicke in der Menüleiste auf **Dienstprogramme** > **Startsicherheitsdienstprogramm**.
2. Wähle dein Startvolume aus (z. B. „Macintosh HD“).
3. Gib dein Passwort ein, falls die Festplatte verschlüsselt ist (FileVault).

---

## Schritt 4: Sicherheitseinstellungen anpassen
1. Klicke auf **Sicherheitsrichtlinie...**.
2. Wähle die Option **Reduzierte Sicherheit**.
3. Aktiviere **Benutzer dürfen Kernel-Erweiterungen von verifizierten Entwicklern verwalten**.
4. Optional nur bei zentral verwalteten Macs: Erlaube die Fernverwaltung von Kernel-Erweiterungen und automatische Updates.
5. Klicke auf **OK**.

---

## Schritt 5: Neustart und Abschluss
1. Starte deinen Mac neu, damit die Änderungen wirksam werden.
2. Nach dem Neustart kannst du Drittanbieter-Kernel-Erweiterungen installieren.
3. Falls ein Hinweis erscheint, dass eine Systemerweiterung blockiert wurde, öffne **Systemeinstellungen** > **Datenschutz & Sicherheit** und erlaube die Erweiterung.

---

## FAQs

**Ist die reduzierte Sicherheit unsicher?**  
Nein, solange du nur Erweiterungen von vertrauenswürdigen, verifizierten Entwicklern installierst, bleibt dein System geschützt.

**Warum erscheint die Option „Sicherheitsrichtlinie“ nicht?**  
Diese Option ist nur auf Apple Silicon Macs verfügbar, nicht auf Intel-basierten Macs.

---

## Support  
Bei Fragen oder Problemen hilft der Apple Support oder spezialisiertes technisches Fachpersonal.

---

https://github.com/macfuse/macfuse/releases


									z.B.
									
						https://github.com/macfuse/macfuse/releases/tag/macfuse-5.0.7
						
						
								.dmg Bitte Installieren.
		
		
		





*Ende des Handbuchs*
