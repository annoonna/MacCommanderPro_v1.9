# ⚡ Quick Start - MacCommander Pro PROFESSIONAL

**Get started in 5 minutes!**

---

## 🚀 Installation (2 minutes)

```bash
# 1. Extract archive
unzip MacCommanderPro_Professional.zip
cd MacCommanderPro_Professional

# 2. Run installer
python3 install.py

# 3. Start app
python3 maccommander_pro.py
```

**Done!** 🎉

---

## 📡 First Connection (2 minutes)

### SFTP Server

1. Click **"📡 Connection Manager"**
2. Click **"➕ New"**
3. Fill in:
   ```
   Profile Name: My Server
   Protocol: SFTP
   Host: server.example.com
   Username: your_username
   Password: ••••••••
   ```
4. Click **"Test Connection"** ✅
5. Click **"OK"**

### Connect

1. Select "My Server"
2. Click **"🔗 Connect"**
3. Wait for 🟢 **Connected!**

---

## 💾 Mount as Volume (1 minute)

1. Click **"💾 Mount"**
2. Volume appears in Finder!
3. Browse files like local folder!

**Location:** `/Volumes/SFTP_server-example`

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| **Ctrl+N** | New Connection |
| **Ctrl+M** | Quick Mount |

---

## 🎯 Common Use Cases

### Development Server

```
Protocol: SFTP
Host: dev.company.com
Port: 22
Remote Path: /var/www/html
Auto-mount: ✅
```

### Windows Share

```
Protocol: SMB
Host: 192.168.1.10
Share: Documents
Username: windowsuser
```

### Cloud Storage

```
Protocol: WebDAV
Host: cloud.example.com/remote.php/dav/files/user
SSL/TLS: ✅
```

---

## 🔧 Required for SFTP Mount

```bash
brew install macfuse
brew install gromgit/fuse/sshfs-mac
sudo reboot
```

**Without these:** SFTP connections work, but mounting doesn't!

---

## 📊 Status Widget

**🔴 Offline** → Not connected  
**🟡 Connecting** → In progress  
**🟢 Connected** → Ready!

**Live Stats:**
- 📤 Upload speed
- 📥 Download speed
- 📊 Latency
- ⏱️ Uptime

---

## 🆘 Problems?

### "SSHFS not available"
```bash
brew install macfuse sshfs-mac
reboot
```

### "Connection refused"
- Check hostname/IP
- Verify port number
- Test with ping/ssh

### "Permission denied"
- Check username/password
- Try SSH key instead
- Verify server access

---

## 📚 More Help

- **README.md** → Full documentation
- **MOUNT_GUIDE.md** → Detailed mount guide
- **PROTOCOLS.md** → Protocol specifics

---

## 🎉 That's It!

You're ready to use MacCommander Pro PROFESSIONAL!

**Tips:**
- Save all your servers as profiles
- Use auto-mount for daily servers
- Check status widget for performance
- Use keyboard shortcuts for speed

---

**Questions?** Check the full documentation! 📖

**Enjoy!** 🚀
