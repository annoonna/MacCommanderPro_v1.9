#!/usr/bin/env python3
"""
MacCommander Pro - Logging System
Logs ALLE Fehler in logs/ Ordner
"""

import logging
import os
from pathlib import Path
from datetime import datetime


class MacCommanderLogger:
    """Logging für MacCommander Pro"""
    
    def __init__(self):
        # Log-Ordner erstellen
        self.log_dir = Path(__file__).parent.parent.parent / "logs"
        self.log_dir.mkdir(exist_ok=True)
        
        # Log-Datei mit Timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / f"maccommander_{timestamp}.log"
        
        # Logger konfigurieren
        self.logger = logging.getLogger("MacCommanderPro")
        self.logger.setLevel(logging.DEBUG)
        
        # File Handler
        file_handler = logging.FileHandler(self.log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        
        # Console Handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Format
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Handler hinzufügen
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        self.logger.info("="*80)
        self.logger.info("MacCommander Pro PROFESSIONAL gestartet")
        self.logger.info(f"Log-Datei: {self.log_file}")
        self.logger.info("="*80)
    
    def info(self, message):
        """Info-Nachricht"""
        self.logger.info(message)
    
    def debug(self, message):
        """Debug-Nachricht"""
        self.logger.debug(message)
    
    def warning(self, message):
        """Warning-Nachricht"""
        self.logger.warning(message)
    
    def error(self, message, exc_info=False):
        """Error-Nachricht"""
        self.logger.error(message, exc_info=exc_info)
    
    def critical(self, message, exc_info=False):
        """Critical-Nachricht"""
        self.logger.critical(message, exc_info=exc_info)


# Globaler Logger
_logger = None

def get_logger():
    """Holt den globalen Logger"""
    global _logger
    if _logger is None:
        _logger = MacCommanderLogger()
    return _logger
