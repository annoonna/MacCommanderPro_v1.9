"""
SFTP/SSH Connection Handler mit Paramiko
"""

import paramiko
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

class SFTPConnection:
    """Verwaltung von SFTP-Verbindungen"""
    
    def __init__(self):
        self.ssh_client = None
        self.sftp_client = None
        self.connected = False
        self.host = None
        self.port = 22
        self.username = None
    
    def connect(self, host: str, username: str, password: str = None, 
                key_file: str = None, port: int = 22) -> bool:
        """
        Verbindet zu SFTP Server
        
        Args:
            host: Hostname oder IP
            username: Benutzername
            password: Passwort (optional)
            key_file: Pfad zu SSH Key (optional)
            port: Port (default: 22)
        
        Returns:
            True bei Erfolg, False bei Fehler
        """
        try:
            # Erstelle SSH Client
            self.ssh_client = paramiko.SSHClient()
            self.ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # Verbindungsparameter
            connect_kwargs = {
                'hostname': host,
                'port': port,
                'username': username,
                'look_for_keys': False,
                'allow_agent': False
            }
            
            # Authentifizierung
            if key_file:
                # Key-basierte Auth
                key = paramiko.RSAKey.from_private_key_file(key_file)
                connect_kwargs['pkey'] = key
            elif password:
                # Passwort-basierte Auth
                connect_kwargs['password'] = password
            else:
                return False
            
            # Verbinden
            self.ssh_client.connect(**connect_kwargs)
            
            # SFTP Session öffnen
            self.sftp_client = self.ssh_client.open_sftp()
            
            self.connected = True
            self.host = host
            self.port = port
            self.username = username
            
            return True
            
        except Exception as e:
            print(f"SFTP Verbindungsfehler: {e}")
            self.disconnect()
            return False
    
    def disconnect(self):
        """Trennt SFTP-Verbindung"""
        if self.sftp_client:
            try:
                self.sftp_client.close()
            except:
                pass
            self.sftp_client = None
        
        if self.ssh_client:
            try:
                self.ssh_client.close()
            except:
                pass
            self.ssh_client = None
        
        self.connected = False
    
    def list_directory(self, path: str = '.') -> List[Dict]:
        """
        Listet Verzeichnisinhalt
        
        Args:
            path: Pfad zum Verzeichnis
        
        Returns:
            Liste von Datei-Dictionaries
        """
        if not self.connected:
            return []
        
        try:
            items = []
            for attr in self.sftp_client.listdir_attr(path):
                item = {
                    'name': attr.filename,
                    'size': attr.st_size or 0,
                    'modified': datetime.fromtimestamp(attr.st_mtime or 0),
                    'is_dir': self._is_directory(attr),
                    'permissions': oct(attr.st_mode)[-3:] if attr.st_mode else '---',
                }
                items.append(item)
            
            # Sortiere: Ordner zuerst, dann alphabetisch
            items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
            
            return items
            
        except Exception as e:
            print(f"Fehler beim Auflisten: {e}")
            return []
    
    def _is_directory(self, attr) -> bool:
        """Prüft ob Attribut ein Verzeichnis ist"""
        import stat
        return stat.S_ISDIR(attr.st_mode) if attr.st_mode else False
    
    def download_file(self, remote_path: str, local_path: str) -> bool:
        """
        Lädt Datei herunter
        
        Args:
            remote_path: Pfad auf Server
            local_path: Lokaler Zielpfad
        
        Returns:
            True bei Erfolg
        """
        if not self.connected:
            return False
        
        try:
            self.sftp_client.get(remote_path, local_path)
            return True
        except Exception as e:
            print(f"Download-Fehler: {e}")
            return False
    
    def upload_file(self, local_path: str, remote_path: str) -> bool:
        """
        Lädt Datei hoch
        
        Args:
            local_path: Lokaler Quellpfad
            remote_path: Pfad auf Server
        
        Returns:
            True bei Erfolg
        """
        if not self.connected:
            return False
        
        try:
            self.sftp_client.put(local_path, remote_path)
            return True
        except Exception as e:
            print(f"Upload-Fehler: {e}")
            return False
    
    def delete_file(self, path: str) -> bool:
        """Löscht Datei"""
        if not self.connected:
            return False
        
        try:
            self.sftp_client.remove(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def create_directory(self, path: str) -> bool:
        """Erstellt Verzeichnis"""
        if not self.connected:
            return False
        
        try:
            self.sftp_client.mkdir(path)
            return True
        except Exception as e:
            print(f"Fehler beim Erstellen: {e}")
            return False
    
    def delete_directory(self, path: str) -> bool:
        """Löscht Verzeichnis"""
        if not self.connected:
            return False
        
        try:
            self.sftp_client.rmdir(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def rename(self, old_path: str, new_path: str) -> bool:
        """Benennt Datei/Ordner um"""
        if not self.connected:
            return False
        
        try:
            self.sftp_client.rename(old_path, new_path)
            return True
        except Exception as e:
            print(f"Umbenennungs-Fehler: {e}")
            return False
    
    def execute_command(self, command: str) -> tuple:
        """
        Führt SSH Kommando aus
        
        Args:
            command: Auszuführendes Kommando
        
        Returns:
            (stdout, stderr, exit_code)
        """
        if not self.connected:
            return ("", "Nicht verbunden", -1)
        
        try:
            stdin, stdout, stderr = self.ssh_client.exec_command(command)
            exit_code = stdout.channel.recv_exit_status()
            
            return (
                stdout.read().decode('utf-8'),
                stderr.read().decode('utf-8'),
                exit_code
            )
        except Exception as e:
            return ("", f"Fehler: {e}", -1)
