"""
Local File System Handler
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Dict

class LocalFileSystem:
    """Verwaltung des lokalen Dateisystems"""
    
    def __init__(self):
        self.connected = True  # Immer "verbunden"
        self.current_path = str(Path.home())
    
    def connect(self, path: str = None) -> bool:
        """Setzt Startverzeichnis"""
        if path and os.path.exists(path):
            self.current_path = path
        else:
            self.current_path = str(Path.home())
        return True
    
    def disconnect(self):
        """Keine Aktion nötig"""
        pass
    
    def list_directory(self, path: str = None) -> List[Dict]:
        """
        Listet Verzeichnisinhalt
        
        Args:
            path: Pfad zum Verzeichnis
        
        Returns:
            Liste von Datei-Dictionaries
        """
        if path is None:
            path = self.current_path
        
        try:
            items = []
            
            with os.scandir(path) as entries:
                for entry in entries:
                    try:
                        stat = entry.stat()
                        
                        item = {
                            'name': entry.name,
                            'size': stat.st_size if entry.is_file() else 0,
                            'modified': datetime.fromtimestamp(stat.st_mtime),
                            'is_dir': entry.is_dir(),
                            'permissions': oct(stat.st_mode)[-3:],
                            'path': entry.path
                        }
                        items.append(item)
                    except (PermissionError, OSError):
                        # Überspringe Dateien ohne Berechtigung
                        continue
            
            # Sortiere: Ordner zuerst, dann alphabetisch
            items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
            
            return items
            
        except Exception as e:
            print(f"Fehler beim Auflisten: {e}")
            return []
    
    def download_file(self, remote_path: str, local_path: str) -> bool:
        """Kopiert Datei (bei lokalem FS ist 'download' = kopieren)"""
        try:
            shutil.copy2(remote_path, local_path)
            return True
        except Exception as e:
            print(f"Kopier-Fehler: {e}")
            return False
    
    def upload_file(self, local_path: str, remote_path: str) -> bool:
        """Kopiert Datei"""
        return self.download_file(local_path, remote_path)
    
    def delete_file(self, path: str) -> bool:
        """Löscht Datei"""
        try:
            os.remove(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def create_directory(self, path: str) -> bool:
        """Erstellt Verzeichnis"""
        try:
            os.makedirs(path, exist_ok=True)
            return True
        except Exception as e:
            print(f"Fehler beim Erstellen: {e}")
            return False
    
    def delete_directory(self, path: str) -> bool:
        """Löscht Verzeichnis"""
        try:
            os.rmdir(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def rename(self, old_path: str, new_path: str) -> bool:
        """Benennt Datei/Ordner um"""
        try:
            os.rename(old_path, new_path)
            return True
        except Exception as e:
            print(f"Umbenennungs-Fehler: {e}")
            return False
    
    def get_drives(self) -> List[str]:
        """Gibt verfügbare Laufwerke zurück (macOS: Volumes)"""
        drives = []
        
        # Hauptverzeichnis
        drives.append('/')
        
        # Benutzerverzeichnis
        drives.append(str(Path.home()))
        
        # macOS Volumes
        volumes_path = Path('/Volumes')
        if volumes_path.exists():
            for volume in volumes_path.iterdir():
                if volume.is_dir():
                    drives.append(str(volume))
        
        return drives
