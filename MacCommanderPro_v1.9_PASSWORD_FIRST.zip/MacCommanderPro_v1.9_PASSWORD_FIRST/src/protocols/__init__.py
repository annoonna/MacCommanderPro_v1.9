"""
Protocol Handler für verschiedene Verbindungstypen
"""

from .sftp_connection import SFTPConnection
from .ftp_connection import FTPConnection
from .local_filesystem import LocalFileSystem

__all__ = ['SFTPConnection', 'FTPConnection', 'LocalFileSystem']
