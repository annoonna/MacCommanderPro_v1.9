"""
SMB/CIFS Connection für Dual-Pane Commander
Verwendet macOS native SMB mounting
"""

import os
import subprocess
from typing import List, Tuple
from pathlib import Path


class SMBConnection:
    """SMB/CIFS Connection mit Mount-Support"""
    
    def __init__(self):
        self.host = None
        self.username = None
        self.share = None
        self.mount_point = None
        self.current_path = "/"
        self.connected = False
    
    def connect(self, host: str, username: str, password: str, 
                port: int = 445, share: str = "share") -> bool:
        """Verbindet mit SMB Share und mounted es"""
        try:
            self.host = host
            self.username = username
            self.share = share
            
            # Mount-Point
            safe_name = f"SMB_{host.replace('.', '_')}_{self.share}"
            self.mount_point = f"/Volumes/{safe_name}"
            
            Path(self.mount_point).mkdir(parents=True, exist_ok=True)
            
            # SMB URL
            smb_url = f"//{username}:{password}@{host}/{self.share}"
            
            # Mount
            cmd = ['mount', '-t', 'smbfs', smb_url, self.mount_point]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            
            if result.returncode == 0:
                self.connected = True
                self.current_path = self.mount_point
                print(f"✅ SMB mounted: {self.mount_point}")
                subprocess.run(['open', self.mount_point])
                return True
            else:
                print(f"❌ SMB mount failed: {result.stderr}")
                try:
                    Path(self.mount_point).rmdir()
                except:
                    pass
                return False
                
        except Exception as e:
            print(f"❌ SMB error: {e}")
            return False
    
    def disconnect(self):
        """Trennt SMB Verbindung"""
        if self.mount_point and Path(self.mount_point).exists():
            try:
                subprocess.run(['umount', self.mount_point], timeout=5)
                Path(self.mount_point).rmdir()
            except:
                pass
        self.connected = False
    
    def list_directory(self, path: str = None) -> List[Tuple]:
        """Listet Verzeichnis-Inhalt"""
        if not self.connected:
            return []
        
        target = path or self.current_path
        if not str(target).startswith(str(self.mount_point)):
            target = Path(self.mount_point) / str(target).lstrip('/')
        
        try:
            items = []
            for entry in Path(target).iterdir():
                try:
                    stat = entry.stat()
                    items.append((entry.name, stat.st_size, stat.st_mtime, entry.is_dir()))
                except:
                    continue
            return sorted(items, key=lambda x: (not x[3], x[0].lower()))
        except Exception as e:
            print(f"❌ List error: {e}")
            return []
    
    def change_directory(self, path: str) -> bool:
        """Wechselt Verzeichnis"""
        if not self.connected:
            return False
        target = Path(self.mount_point) / str(path).lstrip('/')
        if target.is_dir():
            self.current_path = str(target)
            return True
        return False
    
    def get_file(self, remote_path: str, local_path: str, callback=None) -> bool:
        """Kopiert Datei"""
        if not self.connected:
            return False
        try:
            import shutil
            source = Path(self.mount_point) / str(remote_path).lstrip('/')
            shutil.copy2(source, local_path)
            return True
        except Exception as e:
            print(f"❌ Copy error: {e}")
            return False
    
    def put_file(self, local_path: str, remote_path: str, callback=None) -> bool:
        """Upload Datei"""
        if not self.connected:
            return False
        try:
            import shutil
            dest = Path(self.mount_point) / str(remote_path).lstrip('/')
            shutil.copy2(local_path, dest)
            return True
        except Exception as e:
            print(f"❌ Upload error: {e}")
            return False
    
    def delete(self, path: str) -> bool:
        """Löscht Datei/Ordner"""
        if not self.connected:
            return False
        try:
            target = Path(self.mount_point) / str(path).lstrip('/')
            if target.is_dir():
                import shutil
                shutil.rmtree(target)
            else:
                target.unlink()
            return True
        except Exception as e:
            print(f"❌ Delete error: {e}")
            return False
    
    def mkdir(self, path: str) -> bool:
        """Erstellt Verzeichnis"""
        if not self.connected:
            return False
        try:
            target = Path(self.mount_point) / str(path).lstrip('/')
            target.mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            print(f"❌ Mkdir error: {e}")
            return False
    
    def rename(self, old_path: str, new_path: str) -> bool:
        """Benennt um"""
        if not self.connected:
            return False
        try:
            old = Path(self.mount_point) / str(old_path).lstrip('/')
            new = Path(self.mount_point) / str(new_path).lstrip('/')
            old.rename(new)
            return True
        except Exception as e:
            print(f"❌ Rename error: {e}")
            return False
