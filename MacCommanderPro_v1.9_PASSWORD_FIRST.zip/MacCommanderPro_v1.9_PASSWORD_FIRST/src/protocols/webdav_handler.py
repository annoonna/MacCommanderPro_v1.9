#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - WebDAV Protocol Handler
Cloud storage and WebDAV servers support
"""

import os
import subprocess
from typing import List, Optional, Dict, Any
from pathlib import Path
from urllib.parse import urlparse, quote


class WebDAVHandler:
    """Handle WebDAV connections and mounting"""
    
    def __init__(self):
        self.mounted_davs: Dict[str, str] = {}
    
    def connect(self, url: str, username: str, password: str,
                use_ssl: bool = True) -> bool:
        """
        Test WebDAV connection
        
        Args:
            url: WebDAV server URL (e.g., "dav.example.com/files")
            username: Username for authentication
            password: Password
            use_ssl: Use HTTPS (default True)
        
        Returns:
            True if connection successful
        """
        try:
            # Build full URL
            protocol = "https" if use_ssl else "http"
            full_url = f"{protocol}://{url}"
            
            # Parse URL
            parsed = urlparse(full_url)
            if not parsed.scheme or not parsed.netloc:
                return False
            
            # Test with curl
            auth = f"{username}:{password}"
            result = subprocess.run(
                ['curl', '-u', auth, '--head', full_url],
                capture_output=True,
                timeout=10
            )
            
            # WebDAV returns 200 OK or 301/302 redirect
            return result.returncode == 0
            
        except Exception as e:
            print(f"❌ WebDAV connection error: {e}")
            return False
    
    def mount(self, url: str, username: str, password: str,
              use_ssl: bool = True, mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount WebDAV as macOS volume
        
        Args:
            url: WebDAV server URL
            username: Username
            password: Password
            use_ssl: Use HTTPS
            mount_point: Custom mount point
        
        Returns:
            Mount point path if successful
        """
        try:
            # Build full URL with credentials
            protocol = "https" if use_ssl else "http"
            
            # URL encode credentials
            encoded_user = quote(username, safe='')
            encoded_pass = quote(password, safe='')
            
            # Parse URL to extract host and path
            if not url.startswith('http'):
                url = f"{protocol}://{url}"
            
            parsed = urlparse(url)
            host = parsed.netloc
            path = parsed.path or "/"
            
            # Build WebDAV URL
            dav_url = f"{protocol}://{encoded_user}:{encoded_pass}@{host}{path}"
            
            # Create mount point
            if not mount_point:
                mount_name = host.replace('.', '_').replace(':', '_')
                mount_point = f"/Volumes/WebDAV_{mount_name}"
            
            os.makedirs(mount_point, exist_ok=True)
            
            # Mount using macOS mount_webdav
            cmd = ['mount', '-t', 'webdav', dav_url, mount_point]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.mounted_davs[url] = mount_point
                
                # Open in Finder
                subprocess.run(['open', mount_point])
                
                return mount_point
            else:
                error = result.stderr.decode()
                print(f"❌ WebDAV mount failed: {error}")
                
                # Try alternative method with mount_webdav command
                alt_result = subprocess.run(
                    ['mount_webdav', '-i', dav_url, mount_point],
                    capture_output=True,
                    timeout=30
                )
                
                if alt_result.returncode == 0:
                    self.mounted_davs[url] = mount_point
                    subprocess.run(['open', mount_point])
                    return mount_point
                
                return None
                
        except Exception as e:
            print(f"❌ WebDAV mount error: {e}")
            return None
    
    def unmount(self, mount_point: str) -> bool:
        """Unmount WebDAV share"""
        try:
            result = subprocess.run(
                ['umount', mount_point],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Remove from tracked mounts
                for key, path in list(self.mounted_davs.items()):
                    if path == mount_point:
                        del self.mounted_davs[key]
                
                # Remove mount point directory
                try:
                    os.rmdir(mount_point)
                except:
                    pass
                
                return True
            return False
            
        except Exception as e:
            print(f"❌ WebDAV unmount error: {e}")
            return False
    
    def list_files(self, url: str, username: str, password: str,
                   path: str = "/", use_ssl: bool = True) -> List[Dict[str, Any]]:
        """
        List files in WebDAV directory
        
        Args:
            url: WebDAV server URL
            username: Username
            password: Password
            path: Directory path
            use_ssl: Use HTTPS
        
        Returns:
            List of file/directory information
        """
        try:
            protocol = "https" if use_ssl else "http"
            
            if not url.startswith('http'):
                url = f"{protocol}://{url}"
            
            parsed = urlparse(url)
            full_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}{path}"
            
            # Use curl to make PROPFIND request
            auth = f"{username}:{password}"
            
            # XML for PROPFIND
            propfind_xml = '''<?xml version="1.0" encoding="utf-8" ?>
            <D:propfind xmlns:D="DAV:">
                <D:prop>
                    <D:displayname/>
                    <D:getcontentlength/>
                    <D:getlastmodified/>
                    <D:resourcetype/>
                </D:prop>
            </D:propfind>'''
            
            result = subprocess.run(
                ['curl', '-u', auth, '-X', 'PROPFIND',
                 '-H', 'Depth: 1',
                 '-H', 'Content-Type: text/xml',
                 '-d', propfind_xml,
                 full_url],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Parse XML response (simplified)
                # In production, use proper XML parser
                files = []
                output = result.stdout.decode()
                
                # Basic parsing - look for href and displayname
                lines = output.split('\n')
                for i, line in enumerate(lines):
                    if '<D:displayname>' in line:
                        name = line.split('<D:displayname>')[1].split('</D:displayname>')[0]
                        is_dir = '<D:collection/>' in ''.join(lines[i:i+10])
                        
                        files.append({
                            'name': name,
                            'is_dir': is_dir,
                            'size': 0  # Would parse from getcontentlength
                        })
                
                return files
            
            return []
            
        except Exception as e:
            print(f"❌ WebDAV list error: {e}")
            return []
    
    def get_mounted_davs(self) -> Dict[str, str]:
        """Get all currently mounted WebDAV shares"""
        return self.mounted_davs.copy()
    
    def is_mounted(self, url: str) -> bool:
        """Check if WebDAV is mounted"""
        return url in self.mounted_davs
    
    def test_connection(self, url: str, username: str, password: str,
                       use_ssl: bool = True) -> bool:
        """Test WebDAV connection"""
        return self.connect(url, username, password, use_ssl)


class WebDAVCloudProviders:
    """Pre-configured settings for popular WebDAV cloud providers"""
    
    PROVIDERS = {
        'nextcloud': {
            'name': 'Nextcloud',
            'url_pattern': '{host}/remote.php/dav/files/{username}/',
            'default_port': 443,
            'use_ssl': True
        },
        'owncloud': {
            'name': 'ownCloud',
            'url_pattern': '{host}/remote.php/webdav/',
            'default_port': 443,
            'use_ssl': True
        },
        'box': {
            'name': 'Box.com',
            'url_pattern': 'dav.box.com/dav',
            'default_port': 443,
            'use_ssl': True
        },
        'yandex': {
            'name': 'Yandex Disk',
            'url_pattern': 'webdav.yandex.com',
            'default_port': 443,
            'use_ssl': True
        },
        'koofr': {
            'name': 'Koofr',
            'url_pattern': 'app.koofr.net/dav',
            'default_port': 443,
            'use_ssl': True
        }
    }
    
    @classmethod
    def get_provider_url(cls, provider: str, host: str = "", username: str = "") -> str:
        """Get WebDAV URL for a provider"""
        if provider not in cls.PROVIDERS:
            return ""
        
        config = cls.PROVIDERS[provider]
        url_pattern = config['url_pattern']
        
        # Replace placeholders
        url = url_pattern.format(host=host or 'example.com', username=username or 'user')
        
        return url
    
    @classmethod
    def list_providers(cls) -> List[str]:
        """List supported cloud providers"""
        return list(cls.PROVIDERS.keys())
