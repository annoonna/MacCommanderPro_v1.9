#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - SMB/CIFS Protocol Handler
Windows/Samba network shares support
"""

import os
import subprocess
from typing import List, Optional, Dict, Any
from pathlib import Path


class SMBHandler:
    """Handle SMB/CIFS connections and mounting"""
    
    def __init__(self):
        self.mounted_shares: Dict[str, str] = {}
    
    def connect(self, host: str, share: str, username: str, password: str,
                domain: str = "", port: int = 445) -> bool:
        """
        Connect to SMB share
        
        Args:
            host: Server hostname or IP
            share: Share name (e.g., "backup", "documents")
            username: Username for authentication
            password: Password
            domain: Windows domain (optional)
            port: SMB port (default 445)
        
        Returns:
            True if connection successful
        """
        try:
            # Build SMB URL
            if domain:
                smb_url = f"smb://{domain};{username}:{password}@{host}/{share}"
            else:
                smb_url = f"smb://{username}:{password}@{host}/{share}"
            
            # Test connection by listing
            result = subprocess.run(
                ['smbutil', 'view', f"//{username}@{host}"],
                input=password.encode(),
                capture_output=True,
                timeout=10
            )
            
            return result.returncode == 0
            
        except Exception as e:
            print(f"❌ SMB connection error: {e}")
            return False
    
    def mount(self, host: str, share: str, username: str, password: str,
              domain: str = "", mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount SMB share as macOS volume
        
        Args:
            host: Server hostname or IP
            share: Share name
            username: Username
            password: Password
            domain: Windows domain (optional)
            mount_point: Custom mount point (default: /Volumes/ShareName)
        
        Returns:
            Mount point path if successful, None otherwise
        """
        try:
            # Create mount point
            if not mount_point:
                mount_point = f"/Volumes/{share}"
            
            os.makedirs(mount_point, exist_ok=True)
            
            # Build SMB URL
            if domain:
                smb_url = f"smb://{domain};{username}:{password}@{host}/{share}"
            else:
                smb_url = f"smb://{username}:{password}@{host}/{share}"
            
            # Mount using macOS mount_smbfs
            cmd = ['mount', '-t', 'smbfs', smb_url, mount_point]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.mounted_shares[f"{host}/{share}"] = mount_point
                
                # Open in Finder
                subprocess.run(['open', mount_point])
                
                return mount_point
            else:
                print(f"❌ Mount failed: {result.stderr.decode()}")
                return None
                
        except Exception as e:
            print(f"❌ SMB mount error: {e}")
            return None
    
    def unmount(self, mount_point: str) -> bool:
        """Unmount SMB share"""
        try:
            result = subprocess.run(
                ['umount', mount_point],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Remove from tracked mounts
                for key, path in list(self.mounted_shares.items()):
                    if path == mount_point:
                        del self.mounted_shares[key]
                
                # Remove mount point directory
                try:
                    os.rmdir(mount_point)
                except:
                    pass
                
                return True
            return False
            
        except Exception as e:
            print(f"❌ SMB unmount error: {e}")
            return False
    
    def list_shares(self, host: str, username: str, password: str) -> List[str]:
        """List available shares on SMB server"""
        try:
            result = subprocess.run(
                ['smbutil', 'view', f"//{username}@{host}"],
                input=password.encode(),
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                output = result.stdout.decode()
                shares = []
                
                # Parse output for share names
                for line in output.split('\n'):
                    line = line.strip()
                    if line and not line.startswith('Share') and not line.startswith('-'):
                        # Extract share name (first column)
                        parts = line.split()
                        if parts:
                            shares.append(parts[0])
                
                return shares
            
            return []
            
        except Exception as e:
            print(f"❌ List shares error: {e}")
            return []
    
    def get_mounted_shares(self) -> Dict[str, str]:
        """Get all currently mounted shares"""
        return self.mounted_shares.copy()
    
    def is_mounted(self, host: str, share: str) -> bool:
        """Check if share is mounted"""
        key = f"{host}/{share}"
        return key in self.mounted_shares
    
    def test_connection(self, host: str, username: str, password: str) -> bool:
        """Test SMB connection without mounting"""
        try:
            result = subprocess.run(
                ['smbutil', 'status', f"//{username}@{host}"],
                input=password.encode(),
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False


class SMBBrowser:
    """Browse SMB network and discover servers"""
    
    def __init__(self):
        self.handler = SMBHandler()
    
    def discover_servers(self) -> List[str]:
        """Discover SMB servers on local network"""
        try:
            # Use nmblookup to find servers
            result = subprocess.run(
                ['nmblookup', '-M', '--', '-'],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                servers = []
                output = result.stdout.decode()
                
                for line in output.split('\n'):
                    if '<00>' in line:  # Workstation service
                        parts = line.split()
                        if parts:
                            servers.append(parts[0])
                
                return list(set(servers))  # Remove duplicates
            
            return []
            
        except Exception as e:
            print(f"❌ Server discovery error: {e}")
            return []
    
    def get_server_info(self, host: str) -> Dict[str, Any]:
        """Get information about SMB server"""
        try:
            result = subprocess.run(
                ['smbutil', 'lookup', host],
                capture_output=True,
                timeout=5
            )
            
            if result.returncode == 0:
                output = result.stdout.decode()
                
                info = {
                    'host': host,
                    'available': True,
                    'info': output.strip()
                }
                
                return info
            
            return {'host': host, 'available': False}
            
        except Exception as e:
            print(f"❌ Server info error: {e}")
            return {'host': host, 'available': False, 'error': str(e)}
