"""
FTP Connection Handler
"""

import ftplib
from datetime import datetime
from typing import List, Dict

class FTPConnection:
    """Verwaltung von FTP-Verbindungen"""
    
    def __init__(self):
        self.ftp_client = None
        self.connected = False
        self.host = None
        self.port = 21
        self.username = None
    
    def connect(self, host: str, username: str = 'anonymous', 
                password: str = '', port: int = 21, use_tls: bool = False) -> bool:
        """
        Verbindet zu FTP Server
        
        Args:
            host: Hostname oder IP
            username: Benutzername
            password: Passwort
            port: Port (default: 21)
            use_tls: FTPS verwenden
        
        Returns:
            True bei Erfolg
        """
        try:
            # Erstelle FTP Client
            if use_tls:
                self.ftp_client = ftplib.FTP_TLS()
            else:
                self.ftp_client = ftplib.FTP()
            
            # Verbinden
            self.ftp_client.connect(host, port, timeout=30)
            self.ftp_client.login(username, password)
            
            if use_tls:
                # Verschlüssele Datenverbindung
                self.ftp_client.prot_p()
            
            self.connected = True
            self.host = host
            self.port = port
            self.username = username
            
            return True
            
        except Exception as e:
            print(f"FTP Verbindungsfehler: {e}")
            self.disconnect()
            return False
    
    def disconnect(self):
        """Trennt FTP-Verbindung"""
        if self.ftp_client:
            try:
                self.ftp_client.quit()
            except:
                try:
                    self.ftp_client.close()
                except:
                    pass
            self.ftp_client = None
        
        self.connected = False
    
    def list_directory(self, path: str = '.') -> List[Dict]:
        """Listet Verzeichnisinhalt"""
        if not self.connected:
            return []
        
        try:
            items = []
            lines = []
            
            # Wechsle ins Verzeichnis
            self.ftp_client.cwd(path)
            
            # Liste Dateien
            self.ftp_client.retrlines('LIST', lines.append)
            
            for line in lines:
                parts = line.split(None, 8)
                if len(parts) < 9:
                    continue
                
                permissions = parts[0]
                size = int(parts[4]) if parts[4].isdigit() else 0
                name = parts[8]
                
                is_dir = permissions.startswith('d')
                
                item = {
                    'name': name,
                    'size': size,
                    'modified': datetime.now(),  # FTP hat oft kein genaues Datum
                    'is_dir': is_dir,
                    'permissions': permissions
                }
                items.append(item)
            
            # Sortiere
            items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
            
            return items
            
        except Exception as e:
            print(f"Fehler beim Auflisten: {e}")
            return []
    
    def download_file(self, remote_path: str, local_path: str) -> bool:
        """Lädt Datei herunter"""
        if not self.connected:
            return False
        
        try:
            with open(local_path, 'wb') as f:
                self.ftp_client.retrbinary(f'RETR {remote_path}', f.write)
            return True
        except Exception as e:
            print(f"Download-Fehler: {e}")
            return False
    
    def upload_file(self, local_path: str, remote_path: str) -> bool:
        """Lädt Datei hoch"""
        if not self.connected:
            return False
        
        try:
            with open(local_path, 'rb') as f:
                self.ftp_client.storbinary(f'STOR {remote_path}', f)
            return True
        except Exception as e:
            print(f"Upload-Fehler: {e}")
            return False
    
    def delete_file(self, path: str) -> bool:
        """Löscht Datei"""
        if not self.connected:
            return False
        
        try:
            self.ftp_client.delete(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def create_directory(self, path: str) -> bool:
        """Erstellt Verzeichnis"""
        if not self.connected:
            return False
        
        try:
            self.ftp_client.mkd(path)
            return True
        except Exception as e:
            print(f"Fehler beim Erstellen: {e}")
            return False
    
    def delete_directory(self, path: str) -> bool:
        """Löscht Verzeichnis"""
        if not self.connected:
            return False
        
        try:
            self.ftp_client.rmd(path)
            return True
        except Exception as e:
            print(f"Lösch-Fehler: {e}")
            return False
    
    def rename(self, old_path: str, new_path: str) -> bool:
        """Benennt Datei/Ordner um"""
        if not self.connected:
            return False
        
        try:
            self.ftp_client.rename(old_path, new_path)
            return True
        except Exception as e:
            print(f"Umbenennungs-Fehler: {e}")
            return False
