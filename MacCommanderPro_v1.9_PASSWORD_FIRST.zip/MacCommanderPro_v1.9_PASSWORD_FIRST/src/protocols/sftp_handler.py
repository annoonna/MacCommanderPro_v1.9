#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - SFTP Protocol Handler
"""

import paramiko
from typing import List, Optional, Dict, Any
import os
from pathlib import Path


class SFTPHandler:
    """Handle SFTP connections"""
    
    def __init__(self):
        self.client: Optional[paramiko.SSHClient] = None
        self.sftp: Optional[paramiko.SFTPClient] = None
        self.connected = False
    
    def connect(self, host: str, username: str, password: str = "",
                ssh_key: str = "", port: int = 22) -> bool:
        """Connect to SFTP server"""
        try:
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            if ssh_key and os.path.exists(ssh_key):
                # Key-based authentication
                key = paramiko.RSAKey.from_private_key_file(ssh_key)
                self.client.connect(
                    hostname=host,
                    port=port,
                    username=username,
                    pkey=key,
                    timeout=10
                )
            else:
                # Password authentication
                self.client.connect(
                    hostname=host,
                    port=port,
                    username=username,
                    password=password,
                    timeout=10
                )
            
            self.sftp = self.client.open_sftp()
            self.connected = True
            return True
            
        except Exception as e:
            print(f"❌ SFTP connection error: {e}")
            self.connected = False
            return False
    
    def disconnect(self):
        """Disconnect from SFTP server"""
        try:
            if self.sftp:
                self.sftp.close()
            if self.client:
                self.client.close()
            self.connected = False
        except:
            pass
    
    def list_dir(self, path: str = ".") -> List[Dict[str, Any]]:
        """List directory contents"""
        if not self.connected or not self.sftp:
            return []
        
        try:
            items = []
            for item in self.sftp.listdir_attr(path):
                items.append({
                    'name': item.filename,
                    'size': item.st_size,
                    'is_dir': paramiko.sftp_attr.S_ISDIR(item.st_mode),
                    'mtime': item.st_mtime,
                    'mode': item.st_mode
                })
            return items
        except Exception as e:
            print(f"❌ List dir error: {e}")
            return []
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            if self.sftp:
                self.sftp.listdir('.')
                return True
            return False
        except:
            return False


class FTPHandler:
    """Handle FTP/FTPS connections"""
    
    def __init__(self):
        from ftplib import FTP, FTP_TLS
        self.client: Optional[FTP] = None
        self.connected = False
        self.FTP = FTP
        self.FTP_TLS = FTP_TLS
    
    def connect(self, host: str, username: str, password: str,
                port: int = 21, use_ssl: bool = False) -> bool:
        """Connect to FTP server"""
        try:
            if use_ssl:
                self.client = self.FTP_TLS()
            else:
                self.client = self.FTP()
            
            self.client.connect(host, port, timeout=10)
            self.client.login(username, password)
            
            if use_ssl and hasattr(self.client, 'prot_p'):
                self.client.prot_p()
            
            self.connected = True
            return True
            
        except Exception as e:
            print(f"❌ FTP connection error: {e}")
            self.connected = False
            return False
    
    def disconnect(self):
        """Disconnect from FTP server"""
        try:
            if self.client:
                self.client.quit()
            self.connected = False
        except:
            pass
    
    def list_dir(self, path: str = ".") -> List[Dict[str, Any]]:
        """List directory contents"""
        if not self.connected or not self.client:
            return []
        
        try:
            items = []
            self.client.cwd(path)
            
            for item in self.client.mlsd():
                name, facts = item
                is_dir = facts.get('type') == 'dir'
                size = int(facts.get('size', 0))
                
                items.append({
                    'name': name,
                    'size': size,
                    'is_dir': is_dir,
                    'mtime': 0
                })
            
            return items
        except Exception as e:
            print(f"❌ FTP list dir error: {e}")
            return []
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            if self.client:
                self.client.pwd()
                return True
            return False
        except:
            return False
