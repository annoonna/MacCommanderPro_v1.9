"""
Theme Management ohne externe Dependencies
"""

from .theme_manager import ThemeManager

__all__ = ['ThemeManager']
