"""
Theme Manager - Nur mit QPalette, keine externen Dependencies!
"""

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtCore import Qt

class ThemeManager:
    """Theme-Verwaltung ohne externe Dependencies"""
    
    THEMES = {
        'dark': 'Dunkel',
        'light': 'Hell',
    }
    
    COLOR_SCHEMES = {
        'blue': ('Blau', '#2196F3'),
        'green': ('Grün', '#4CAF50'),
        'purple': ('Lila', '#9C27B0'),
        'pink': ('Rosa', '#E91E63'),
        'orange': ('Orange', '#FF9800'),
        'red': ('Rot', '#F44336'),
    }
    
    def __init__(self):
        self.current_theme = 'dark'
        self.current_color = 'blue'
        self.app = QApplication.instance()
    
    def apply_theme(self, theme='dark', color='blue'):
        """Wendet Theme an"""
        self.current_theme = theme
        self.current_color = color
        
        if not self.app:
            return
        
        # Wende Palette an
        if theme == 'dark':
            self._apply_dark_theme(color)
        else:
            self._apply_light_theme(color)
        
        # Stylesheet für zusätzliche Anpassungen
        self.app.setStyleSheet(self._get_stylesheet(theme, color))
    
    def _apply_dark_theme(self, color):
        """Dunkles Theme"""
        palette = QPalette()
        accent = self.COLOR_SCHEMES[color][1]
        
        # Haupt farben
        palette.setColor(QPalette.ColorRole.Window, QColor(45, 45, 45))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Base, QColor(30, 30, 30))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(45, 45, 45))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(20, 20, 20))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Button, QColor(45, 45, 45))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Link, QColor(accent))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(accent))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        
        # Deaktivierte Elemente
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(128, 128, 128))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(128, 128, 128))
        
        self.app.setPalette(palette)
    
    def _apply_light_theme(self, color):
        """Helles Theme"""
        palette = QPalette()
        accent = self.COLOR_SCHEMES[color][1]
        
        # Hauptfarben
        palette.setColor(QPalette.ColorRole.Window, QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(245, 245, 245))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 220))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Text, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Button, QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Link, QColor(accent))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(accent))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        
        # Deaktivierte Elemente
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(128, 128, 128))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(128, 128, 128))
        
        self.app.setPalette(palette)
    
    def _get_stylesheet(self, theme, color):
        """Generiert Stylesheet"""
        accent = self.COLOR_SCHEMES[color][1]
        
        if theme == 'dark':
            bg = '#2d2d2d'
            fg = '#ffffff'
            border = '#3d3d3d'
        else:
            bg = '#f0f0f0'
            fg = '#000000'
            border = '#d0d0d0'
        
        return f"""
        QMainWindow {{
            background-color: {bg};
        }}
        
        QToolBar {{
            background-color: {bg};
            border: 1px solid {border};
            padding: 4px;
            spacing: 3px;
        }}
        
        QToolButton {{
            background-color: transparent;
            border: none;
            border-radius: 4px;
            padding: 6px;
            color: {fg};
        }}
        
        QToolButton:hover {{
            background-color: {accent};
            color: white;
        }}
        
        QMenuBar {{
            background-color: {bg};
            color: {fg};
        }}
        
        QMenuBar::item:selected {{
            background-color: {accent};
        }}
        
        QMenu {{
            background-color: {bg};
            color: {fg};
            border: 1px solid {border};
        }}
        
        QMenu::item:selected {{
            background-color: {accent};
        }}
        
        QTabWidget::pane {{
            border: 1px solid {border};
            background-color: {bg};
        }}
        
        QTabBar::tab {{
            background-color: {bg};
            color: {fg};
            border: 1px solid {border};
            padding: 8px 16px;
            margin-right: 2px;
        }}
        
        QTabBar::tab:selected {{
            background-color: {accent};
            color: white;
        }}
        
        QTabBar::tab:hover {{
            background-color: {accent};
            opacity: 0.8;
        }}
        
        QTreeWidget {{
            background-color: {bg};
            alternate-background-color: {border};
            color: {fg};
            border: 1px solid {border};
        }}
        
        QTreeWidget::item:selected {{
            background-color: {accent};
            color: white;
        }}
        
        QHeaderView::section {{
            background-color: {bg};
            color: {fg};
            padding: 4px;
            border: 1px solid {border};
        }}
        
        QScrollBar:vertical {{
            border: none;
            background: {bg};
            width: 12px;
            margin: 0;
        }}
        
        QScrollBar::handle:vertical {{
            background: {accent};
            border-radius: 6px;
            min-height: 20px;
        }}
        
        QScrollBar::handle:vertical:hover {{
            background: {accent};
            opacity: 0.8;
        }}
        
        QProgressBar {{
            border: 1px solid {border};
            border-radius: 4px;
            text-align: center;
            background-color: {bg};
            color: {fg};
        }}
        
        QProgressBar::chunk {{
            background-color: {accent};
            border-radius: 4px;
        }}
        
        QPushButton {{
            background-color: {accent};
            color: white;
            border: none;
            border-radius: 4px;
            padding: 6px 16px;
            font-weight: bold;
        }}
        
        QPushButton:hover {{
            background-color: {accent};
            opacity: 0.9;
        }}
        
        QPushButton:pressed {{
            background-color: {accent};
            opacity: 0.8;
        }}
        
        QLineEdit {{
            background-color: {bg};
            color: {fg};
            border: 1px solid {border};
            border-radius: 4px;
            padding: 6px;
        }}
        
        QLineEdit:focus {{
            border: 2px solid {accent};
        }}
        
        QStatusBar {{
            background-color: {bg};
            color: {fg};
            border-top: 1px solid {border};
        }}
        """
