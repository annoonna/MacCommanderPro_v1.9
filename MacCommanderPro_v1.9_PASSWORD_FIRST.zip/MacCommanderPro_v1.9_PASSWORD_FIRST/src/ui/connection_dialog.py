#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Connection Manager Dialog
Manage all connection profiles with beautiful UI
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
                              QListWidget, QListWidgetItem, QLabel, QLineEdit,
                              QComboBox, QSpinBox, QCheckBox, QGroupBox,
                              QMessageBox, QDialogButtonBox, QFormLayout,
                              QTextEdit, QTabWidget, QWidget, QFileDialog)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QIcon
from typing import Optional, Dict, Any


class ConnectionDialog(QDialog):
    """Dialog for creating/editing connection profiles"""
    
    def __init__(self, parent=None, profile: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.profile = profile
        self.setWindowTitle("Connection Profile" if not profile else f"Edit: {profile.get('name', 'Connection')}")
        self.setMinimumWidth(500)
        self._setup_ui()
        
        if profile:
            self._load_profile(profile)
    
    def _setup_ui(self):
        """Setup dialog UI"""
        layout = QVBoxLayout(self)
        
        # Tabs for different settings - REPARIERT!
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        self.tabs.setDocumentMode(False)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.setElideMode(Qt.TextElideMode.ElideNone)
        
        # Basic settings tab
        basic_tab = QWidget()
        basic_layout = QFormLayout(basic_tab)
        basic_layout.setSpacing(10)
        basic_layout.setContentsMargins(15, 15, 15, 15)
        
        # Profile name
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("My Server")
        basic_layout.addRow("Profile Name:", self.name_edit)
        
        # Protocol
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["SFTP", "FTP", "FTPS", "SMB", "WebDAV"])
        self.protocol_combo.currentTextChanged.connect(self._on_protocol_changed)
        basic_layout.addRow("Protocol:", self.protocol_combo)
        
        # Host
        self.host_edit = QLineEdit()
        self.host_edit.setPlaceholderText("server.example.com")
        basic_layout.addRow("Host:", self.host_edit)
        
        # Port
        self.port_spin = QSpinBox()
        self.port_spin.setMinimum(1)
        self.port_spin.setMaximum(65535)
        self.port_spin.setValue(22)
        basic_layout.addRow("Port:", self.port_spin)
        
        # Username
        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("username")
        basic_layout.addRow("Username:", self.username_edit)
        
        # Password
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_edit.setPlaceholderText("••••••••")
        basic_layout.addRow("Password:", self.password_edit)
        
        self.tabs.addTab(basic_tab, "Basic")
        
        # Advanced settings tab
        advanced_tab = QWidget()
        advanced_layout = QFormLayout(advanced_tab)
        advanced_layout.setSpacing(10)
        advanced_layout.setContentsMargins(15, 15, 15, 15)
        
        # SSH Key (for SFTP)
        self.ssh_key_edit = QLineEdit()
        self.ssh_key_edit.setPlaceholderText("~/.ssh/id_rsa")
        self.ssh_key_button = QPushButton("Browse...")
        self.ssh_key_button.clicked.connect(self._browse_ssh_key)
        ssh_key_layout = QHBoxLayout()
        ssh_key_layout.addWidget(self.ssh_key_edit, 1)
        ssh_key_layout.addWidget(self.ssh_key_button)
        ssh_key_widget = QWidget()
        ssh_key_widget.setLayout(ssh_key_layout)
        self.ssh_key_label = QLabel("SSH Key:")
        advanced_layout.addRow(self.ssh_key_label, ssh_key_widget)
        
        # SSL/TLS
        self.ssl_check = QCheckBox("Use SSL/TLS")
        self.ssl_check.setChecked(True)
        self.ssl_label = QLabel("Security:")
        advanced_layout.addRow(self.ssl_label, self.ssl_check)
        
        # SMB Domain
        self.domain_edit = QLineEdit()
        self.domain_edit.setPlaceholderText("WORKGROUP")
        self.domain_label = QLabel("Domain:")
        advanced_layout.addRow(self.domain_label, self.domain_edit)
        
        # SMB Share
        self.share_edit = QLineEdit()
        self.share_edit.setPlaceholderText("share_name")
        self.share_label = QLabel("Share:")
        advanced_layout.addRow(self.share_label, self.share_edit)
        
        self.tabs.addTab(advanced_tab, "Advanced")
        
        # Mount settings tab
        mount_tab = QWidget()
        mount_layout = QFormLayout(mount_tab)
        mount_layout.setSpacing(10)
        mount_layout.setContentsMargins(15, 15, 15, 15)
        
        # Auto-mount
        self.auto_mount_check = QCheckBox("Auto-mount on connect")
        mount_layout.addRow("Auto-mount:", self.auto_mount_check)
        
        # Mount point
        self.mount_point_edit = QLineEdit()
        self.mount_point_edit.setPlaceholderText("/Volumes/MyServer (auto)")
        mount_layout.addRow("Mount Point:", self.mount_point_edit)
        
        # Remote path
        self.remote_path_edit = QLineEdit()
        self.remote_path_edit.setPlaceholderText("/")
        mount_layout.addRow("Remote Path:", self.remote_path_edit)
        
        self.tabs.addTab(mount_tab, "Mount")
        
        # ADD TABS TO LAYOUT!
        layout.addWidget(self.tabs)
        
        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        
        # Test Connection button
        self.test_button = QPushButton("Test Connection")
        self.test_button.clicked.connect(self._test_connection)
        button_box.addButton(self.test_button, QDialogButtonBox.ButtonRole.ActionRole)
        
        layout.addWidget(button_box)
        
        # Update UI based on protocol
        self._on_protocol_changed(self.protocol_combo.currentText())
    
    def _on_protocol_changed(self, protocol: str):
        """Update UI based on selected protocol"""
        # SSH key - only for SFTP
        show_ssh_key = protocol == "SFTP"
        self.ssh_key_label.setVisible(show_ssh_key)
        self.ssh_key_edit.setVisible(show_ssh_key)
        self.ssh_key_button.setVisible(show_ssh_key)
        
        # SSL/TLS - for FTP and WebDAV
        show_ssl = protocol in ["FTP", "FTPS", "WebDAV"]
        self.ssl_label.setVisible(show_ssl)
        self.ssl_check.setVisible(show_ssl)
        
        # SMB specific
        show_smb = protocol == "SMB"
        self.domain_label.setVisible(show_smb)
        self.domain_edit.setVisible(show_smb)
        self.share_label.setVisible(show_smb)
        self.share_edit.setVisible(show_smb)
        
        # Set default ports
        default_ports = {
            "SFTP": 22,
            "FTP": 21,
            "FTPS": 990,
            "SMB": 445,
            "WebDAV": 443
        }
        self.port_spin.setValue(default_ports.get(protocol, 22))
    
    def _browse_ssh_key(self):
        """Browse for SSH key file"""
        from pathlib import Path
        home = str(Path.home())
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Select SSH Private Key",
            f"{home}/.ssh",
            "All Files (*)"
        )
        if filename:
            self.ssh_key_edit.setText(filename)
    
    def _test_connection(self):
        """Test the connection with current settings"""
        QMessageBox.information(
            self,
            "Test Connection",
            "Testing connection...\n(Full implementation with actual connection test)"
        )
    
    def _load_profile(self, profile: Dict[str, Any]):
        """Load profile data into form"""
        self.name_edit.setText(profile.get('name', ''))
        self.host_edit.setText(profile.get('host', ''))
        self.port_spin.setValue(profile.get('port', 22))
        self.username_edit.setText(profile.get('username', ''))
        
        protocol = profile.get('protocol', 'sftp').upper()
        index = self.protocol_combo.findText(protocol)
        if index >= 0:
            self.protocol_combo.setCurrentIndex(index)
        
        self.ssh_key_edit.setText(profile.get('ssh_key', ''))
        self.ssl_check.setChecked(profile.get('use_ssl', False))
        self.domain_edit.setText(profile.get('domain', ''))
        self.share_edit.setText(profile.get('share', ''))
        self.auto_mount_check.setChecked(profile.get('auto_mount', False))
        self.mount_point_edit.setText(profile.get('mount_point', ''))
    
    def get_profile(self) -> Dict[str, Any]:
        """Get profile data from form"""
        protocol = self.protocol_combo.currentText().lower()
        if protocol == "ftps":
            protocol = "ftp"
            use_ssl = True
        else:
            use_ssl = self.ssl_check.isChecked()
        
        return {
            'name': self.name_edit.text(),
            'protocol': protocol,
            'host': self.host_edit.text(),
            'port': self.port_spin.value(),
            'username': self.username_edit.text(),
            'password': self.password_edit.text(),
            'ssh_key': self.ssh_key_edit.text(),
            'use_ssl': use_ssl,
            'domain': self.domain_edit.text(),
            'share': self.share_edit.text(),
            'auto_mount': self.auto_mount_check.isChecked(),
            'mount_point': self.mount_point_edit.text(),
            'remote_path': self.remote_path_edit.text()
        }


class ConnectionManagerDialog(QDialog):
    """Main connection manager dialog"""
    
    connect_requested = pyqtSignal(str)  # profile name
    disconnect_requested = pyqtSignal(str)
    mount_requested = pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.profiles: Dict[str, Dict[str, Any]] = {}
        self.setWindowTitle("Connection Manager")
        self.setMinimumSize(700, 500)
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup manager UI"""
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("📡 Connection Manager")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        
        subtitle = QLabel("Manage your server connections")
        subtitle.setStyleSheet("color: #888888;")
        layout.addWidget(subtitle)
        
        # Main content
        content_layout = QHBoxLayout()
        
        # Connection list
        list_layout = QVBoxLayout()
        
        list_label = QLabel("Saved Connections:")
        list_layout.addWidget(list_label)
        
        self.connection_list = QListWidget()
        self.connection_list.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.connection_list.currentItemChanged.connect(self._on_selection_changed)
        list_layout.addWidget(self.connection_list)
        
        # List buttons
        list_buttons = QHBoxLayout()
        
        add_button = QPushButton("➕ New")
        add_button.clicked.connect(self._add_connection)
        list_buttons.addWidget(add_button)
        
        edit_button = QPushButton("✏️ Edit")
        edit_button.clicked.connect(self._edit_connection)
        self.edit_button = edit_button
        list_buttons.addWidget(edit_button)
        
        delete_button = QPushButton("🗑️ Delete")
        delete_button.clicked.connect(self._delete_connection)
        self.delete_button = delete_button
        list_buttons.addWidget(delete_button)
        
        list_layout.addLayout(list_buttons)
        content_layout.addLayout(list_layout, stretch=1)
        
        # Connection details
        details_group = QGroupBox("Connection Details")
        details_layout = QVBoxLayout(details_group)
        
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setMaximumHeight(200)
        details_layout.addWidget(self.details_text)
        
        # Action buttons
        action_buttons = QVBoxLayout()
        
        self.connect_button = QPushButton("🔗 Connect")
        self.connect_button.clicked.connect(self._connect_profile)
        self.connect_button.setEnabled(False)
        self.connect_button.setMinimumHeight(40)
        action_buttons.addWidget(self.connect_button)
        
        self.disconnect_button = QPushButton("🔌 Disconnect")
        self.disconnect_button.clicked.connect(self._disconnect_profile)
        self.disconnect_button.setEnabled(False)
        action_buttons.addWidget(self.disconnect_button)
        
        self.mount_button = QPushButton("💾 Mount")
        self.mount_button.clicked.connect(self._mount_profile)
        self.mount_button.setEnabled(False)
        action_buttons.addWidget(self.mount_button)
        
        action_buttons.addStretch()
        
        details_layout.addLayout(action_buttons)
        content_layout.addWidget(details_group, stretch=1)
        
        layout.addLayout(content_layout)
        
        # Bottom buttons
        bottom_buttons = QHBoxLayout()
        bottom_buttons.addStretch()
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        bottom_buttons.addWidget(close_button)
        
        layout.addLayout(bottom_buttons)
        
        self._update_button_states()
    
    def _on_selection_changed(self, current, previous):
        """Handle selection change"""
        if current:
            profile_name = current.text().split(' - ')[0]
            profile = self.profiles.get(profile_name)
            if profile:
                self._show_profile_details(profile)
        
        self._update_button_states()
    
    def _on_item_double_clicked(self, item):
        """Handle double click - connect"""
        self._connect_profile()
    
    def _show_profile_details(self, profile: Dict[str, Any]):
        """Show profile details"""
        details = f"""<b>Name:</b> {profile.get('name', 'N/A')}<br>
<b>Protocol:</b> {profile.get('protocol', 'N/A').upper()}<br>
<b>Host:</b> {profile.get('host', 'N/A')}<br>
<b>Port:</b> {profile.get('port', 'N/A')}<br>
<b>Username:</b> {profile.get('username', 'N/A')}<br>"""
        
        if profile.get('auto_mount'):
            details += "<br><b>Auto-mount:</b> Yes"
        
        if profile.get('mount_point'):
            details += f"<br><b>Mount Point:</b> {profile.get('mount_point')}"
        
        self.details_text.setHtml(details)
    
    def _add_connection(self):
        """Add new connection"""
        dialog = ConnectionDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            profile = dialog.get_profile()
            name = profile['name']
            
            if not name:
                QMessageBox.warning(self, "Invalid Name", "Please enter a profile name.")
                return
            
            if name in self.profiles:
                QMessageBox.warning(self, "Duplicate Name", "A profile with this name already exists.")
                return
            
            self.add_profile(profile)
    
    def _edit_connection(self):
        """Edit selected connection"""
        current = self.connection_list.currentItem()
        if not current:
            return
        
        profile_name = current.text().split(' - ')[0]
        profile = self.profiles.get(profile_name)
        
        if not profile:
            return
        
        dialog = ConnectionDialog(self, profile)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_profile = dialog.get_profile()
            
            # Remove old if name changed
            if new_profile['name'] != profile_name:
                del self.profiles[profile_name]
            
            self.add_profile(new_profile)
    
    def _delete_connection(self):
        """Delete selected connection"""
        current = self.connection_list.currentItem()
        if not current:
            return
        
        profile_name = current.text().split(' - ')[0]
        
        reply = QMessageBox.question(
            self,
            "Delete Connection",
            f"Delete connection '{profile_name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            if profile_name in self.profiles:
                del self.profiles[profile_name]
                self.connection_list.takeItem(self.connection_list.currentRow())
                self._update_button_states()
    
    def _connect_profile(self):
        """Connect to selected profile"""
        current = self.connection_list.currentItem()
        if current:
            profile_name = current.text().split(' - ')[0]
            self.connect_requested.emit(profile_name)
    
    def _disconnect_profile(self):
        """Disconnect selected profile"""
        current = self.connection_list.currentItem()
        if current:
            profile_name = current.text().split(' - ')[0]
            self.disconnect_requested.emit(profile_name)
    
    def _mount_profile(self):
        """Mount selected profile"""
        current = self.connection_list.currentItem()
        if current:
            profile_name = current.text().split(' - ')[0]
            self.mount_requested.emit(profile_name)
    
    def _update_button_states(self):
        """Update button enabled states"""
        has_selection = self.connection_list.currentItem() is not None
        
        self.edit_button.setEnabled(has_selection)
        self.delete_button.setEnabled(has_selection)
        self.connect_button.setEnabled(has_selection)
        self.disconnect_button.setEnabled(has_selection)
        self.mount_button.setEnabled(has_selection)
    
    def add_profile(self, profile: Dict[str, Any]):
        """Add profile to list"""
        name = profile['name']
        self.profiles[name] = profile
        
        # Add to list
        item_text = f"{name} - {profile.get('protocol', '').upper()}://{profile.get('host', '')}"
        
        # Check if already in list
        for i in range(self.connection_list.count()):
            if self.connection_list.item(i).text().startswith(name + " -"):
                self.connection_list.takeItem(i)
                break
        
        item = QListWidgetItem(item_text)
        self.connection_list.addItem(item)
    
    def get_profiles(self) -> Dict[str, Dict[str, Any]]:
        """Get all profiles"""
        return self.profiles.copy()
    
    def set_profiles(self, profiles: Dict[str, Dict[str, Any]]):
        """Set profiles"""
        self.profiles = profiles.copy()
        self.connection_list.clear()
        
        for profile in profiles.values():
            self.add_profile(profile)
