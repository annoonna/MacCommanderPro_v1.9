#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Neon Status Widget
Real-time connection status with beautiful NEON display
"""

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QPushButton, QFrame, QGroupBox)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPalette, QColor
from datetime import datetime, timedelta
from typing import Optional


class NeonStatusWidget(QWidget):
    """
    Beautiful NEON status display with live stats
    
    Shows:
    - 🔴 Offline / 🟡 Connecting / 🟢 Connected
    - Speed (upload/download)
    - Latency
    - Uptime
    - Connection details
    """
    
    details_clicked = pyqtSignal()
    disconnect_clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.status = "offline"
        self.connection_name = ""
        self.protocol = ""
        
        # Stats
        self.upload_speed = 0.0
        self.download_speed = 0.0
        self.latency = 0
        self.uptime_seconds = 0
        self.bytes_sent = 0
        self.bytes_received = 0
        
        self._setup_ui()
        self._start_update_timer()
    
    def _setup_ui(self):
        """Setup beautiful neon UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        
        # Status Group
        status_group = QGroupBox("Connection Status")
        status_layout = QVBoxLayout(status_group)
        
        # Main status indicator with NEON effect
        self.status_label = QLabel("🔴 Offline")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_font = QFont()
        status_font.setPointSize(16)
        status_font.setBold(True)
        self.status_label.setFont(status_font)
        self.status_label.setMinimumHeight(50)
        status_layout.addWidget(self.status_label)
        
        # Connection info
        self.info_label = QLabel("No active connection")
        self.info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info_label.setStyleSheet("color: #888888;")
        status_layout.addWidget(self.info_label)
        
        layout.addWidget(status_group)
        
        # Stats Group
        self.stats_group = QGroupBox("Live Statistics")
        stats_layout = QVBoxLayout(self.stats_group)
        
        # Speed indicators
        speed_layout = QHBoxLayout()
        
        # Upload speed
        upload_widget = self._create_stat_widget("📤 Upload", "0.0 MB/s")
        self.upload_label = upload_widget.findChild(QLabel, "value")
        speed_layout.addWidget(upload_widget)
        
        # Download speed
        download_widget = self._create_stat_widget("📥 Download", "0.0 MB/s")
        self.download_label = download_widget.findChild(QLabel, "value")
        speed_layout.addWidget(download_widget)
        
        stats_layout.addLayout(speed_layout)
        
        # Latency and Uptime
        info_layout = QHBoxLayout()
        
        # Latency
        latency_widget = self._create_stat_widget("📊 Latency", "0 ms")
        self.latency_label = latency_widget.findChild(QLabel, "value")
        info_layout.addWidget(latency_widget)
        
        # Uptime
        uptime_widget = self._create_stat_widget("⏱️ Uptime", "0m 0s")
        self.uptime_label = uptime_widget.findChild(QLabel, "value")
        info_layout.addWidget(uptime_widget)
        
        stats_layout.addLayout(info_layout)
        
        # Transfer totals
        total_layout = QHBoxLayout()
        
        sent_widget = self._create_stat_widget("📤 Sent", "0 MB")
        self.sent_label = sent_widget.findChild(QLabel, "value")
        total_layout.addWidget(sent_widget)
        
        received_widget = self._create_stat_widget("📥 Received", "0 MB")
        self.received_label = received_widget.findChild(QLabel, "value")
        total_layout.addWidget(received_widget)
        
        stats_layout.addLayout(total_layout)
        
        layout.addWidget(self.stats_group)
        self.stats_group.setVisible(False)  # Hidden when offline
        
        # Action buttons
        button_layout = QHBoxLayout()
        
        self.details_button = QPushButton("Details")
        self.details_button.clicked.connect(self.details_clicked.emit)
        self.details_button.setEnabled(False)
        button_layout.addWidget(self.details_button)
        
        self.disconnect_button = QPushButton("Disconnect")
        self.disconnect_button.clicked.connect(self.disconnect_clicked.emit)
        self.disconnect_button.setEnabled(False)
        button_layout.addWidget(self.disconnect_button)
        
        layout.addLayout(button_layout)
        
        layout.addStretch()
    
    def _create_stat_widget(self, label: str, value: str) -> QWidget:
        """Create a stat display widget"""
        widget = QFrame()
        widget.setFrameShape(QFrame.Shape.StyledPanel)
        widget_layout = QVBoxLayout(widget)
        widget_layout.setContentsMargins(5, 5, 5, 5)
        
        label_widget = QLabel(label)
        label_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label_widget.setStyleSheet("color: #888888; font-size: 10px;")
        widget_layout.addWidget(label_widget)
        
        value_widget = QLabel(value)
        value_widget.setObjectName("value")
        value_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = QFont()
        font.setBold(True)
        font.setPointSize(12)
        value_widget.setFont(font)
        widget_layout.addWidget(value_widget)
        
        return widget
    
    def _start_update_timer(self):
        """Start timer for updating display"""
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self._update_display)
        self.update_timer.start(1000)  # Update every second
    
    def _update_display(self):
        """Update the display with current stats"""
        # Update uptime
        if self.status == "connected" and self.uptime_seconds > 0:
            self.uptime_seconds += 1
            uptime_str = self._format_uptime(self.uptime_seconds)
            self.uptime_label.setText(uptime_str)
    
    def _format_uptime(self, seconds: int) -> str:
        """Format uptime as human-readable string"""
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        
        if hours > 0:
            return f"{hours}h {minutes}m"
        elif minutes > 0:
            return f"{minutes}m {secs}s"
        else:
            return f"{secs}s"
    
    def _format_bytes(self, bytes_value: int) -> str:
        """Format bytes as human-readable string"""
        if bytes_value >= 1_000_000_000:
            return f"{bytes_value / 1_000_000_000:.2f} GB"
        elif bytes_value >= 1_000_000:
            return f"{bytes_value / 1_000_000:.2f} MB"
        elif bytes_value >= 1_000:
            return f"{bytes_value / 1_000:.2f} KB"
        else:
            return f"{bytes_value} B"
    
    def set_offline(self):
        """Set status to offline"""
        self.status = "offline"
        self.status_label.setText("🔴 Offline")
        self.status_label.setStyleSheet("color: #FF0000;")
        self.info_label.setText("No active connection")
        self.stats_group.setVisible(False)
        self.details_button.setEnabled(False)
        self.disconnect_button.setEnabled(False)
        
        # Reset stats
        self.uptime_seconds = 0
        self.upload_speed = 0.0
        self.download_speed = 0.0
        self.latency = 0
    
    def set_connecting(self, name: str = "", protocol: str = ""):
        """Set status to connecting"""
        self.status = "connecting"
        self.connection_name = name
        self.protocol = protocol
        
        self.status_label.setText("🟡 Connecting...")
        self.status_label.setStyleSheet("color: #FFFF00;")
        
        info = f"Connecting to {name}" if name else "Connecting..."
        if protocol:
            info += f" ({protocol.upper()})"
        self.info_label.setText(info)
        
        self.stats_group.setVisible(False)
        self.details_button.setEnabled(False)
        self.disconnect_button.setEnabled(True)
    
    def set_connected(self, name: str = "", protocol: str = "", host: str = ""):
        """Set status to connected"""
        self.status = "connected"
        self.connection_name = name
        self.protocol = protocol
        
        self.status_label.setText("🟢 Connected!")
        self.status_label.setStyleSheet("color: #00FF00;")
        
        info = f"Connected to {name}" if name else "Connected"
        if host:
            info += f" ({host})"
        if protocol:
            info += f" - {protocol.upper()}"
        self.info_label.setText(info)
        
        self.stats_group.setVisible(True)
        self.details_button.setEnabled(True)
        self.disconnect_button.setEnabled(True)
        
        # Reset uptime
        self.uptime_seconds = 0
    
    def set_error(self, message: str = "Connection error"):
        """Set status to error"""
        self.status = "error"
        self.status_label.setText("🔴 Error")
        self.status_label.setStyleSheet("color: #FF0000;")
        self.info_label.setText(message)
        self.stats_group.setVisible(False)
        self.details_button.setEnabled(False)
        self.disconnect_button.setEnabled(False)
    
    def update_stats(self, upload_speed: float = 0.0, download_speed: float = 0.0,
                     latency: int = 0, bytes_sent: int = 0, bytes_received: int = 0):
        """Update connection statistics"""
        self.upload_speed = upload_speed
        self.download_speed = download_speed
        self.latency = latency
        self.bytes_sent = bytes_sent
        self.bytes_received = bytes_received
        
        # Update labels
        self.upload_label.setText(f"{upload_speed:.2f} MB/s")
        self.download_label.setText(f"{download_speed:.2f} MB/s")
        self.latency_label.setText(f"{latency} ms")
        self.sent_label.setText(self._format_bytes(bytes_sent))
        self.received_label.setText(self._format_bytes(bytes_received))
        
        # Color code latency
        if latency < 50:
            self.latency_label.setStyleSheet("color: #00FF00;")  # Green
        elif latency < 150:
            self.latency_label.setStyleSheet("color: #FFFF00;")  # Yellow
        else:
            self.latency_label.setStyleSheet("color: #FF0000;")  # Red


class CompactStatusWidget(QWidget):
    """Compact status indicator for toolbar"""
    
    clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.status = "offline"
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup compact UI"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 2, 5, 2)
        
        self.icon_label = QLabel("🔴")
        font = QFont()
        font.setPointSize(14)
        self.icon_label.setFont(font)
        layout.addWidget(self.icon_label)
        
        self.text_label = QLabel("Offline")
        layout.addWidget(self.text_label)
        
        self.setCursor(Qt.CursorShape.PointingHandCursor)
    
    def mousePressEvent(self, event):
        """Handle click"""
        self.clicked.emit()
        super().mousePressEvent(event)
    
    def set_status(self, status: str, text: str = ""):
        """Update status"""
        self.status = status
        
        if status == "offline":
            self.icon_label.setText("🔴")
            self.text_label.setText("Offline")
        elif status == "connecting":
            self.icon_label.setText("🟡")
            self.text_label.setText("Connecting..." if not text else text)
        elif status == "connected":
            self.icon_label.setText("🟢")
            self.text_label.setText("Connected" if not text else text)
        elif status == "error":
            self.icon_label.setText("🔴")
            self.text_label.setText("Error" if not text else text)
