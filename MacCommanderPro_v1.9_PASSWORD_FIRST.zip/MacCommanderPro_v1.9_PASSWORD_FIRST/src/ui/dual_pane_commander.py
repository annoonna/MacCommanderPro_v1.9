"""
Dual-Pane File Commander
Midnight Commander-Style mit F-Keys, Copy, Move, Delete, Drag & Drop
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QTreeWidget, QTreeWidgetItem, QLineEdit, QPushButton,
    QLabel, QMessageBox, QMenu, QProgressDialog, QInputDialog,
    QFileDialog, QDialog, QDialogButtonBox
)
from PyQt6.QtCore import Qt, QDir, pyqtSignal, QMimeData, QUrl
from PyQt6.QtGui import QDragEnterEvent, QDropEvent, QKeySequence, QShortcut

from pathlib import Path
from ..protocols.sftp_connection import SFTPConnection
from ..protocols.ftp_connection import FTPConnection
from ..protocols.local_filesystem import LocalFileSystem

class FilePanel(QWidget):
    """Ein einzelnes Datei-Panel"""
    
    # Signals
    path_changed = pyqtSignal(str)
    selection_changed = pyqtSignal(list)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.connection = None
        self.connection_type = None
        self.current_path = str(Path.home())
        self.selected_items = []
        
        self.init_ui()
        self.setAcceptDrops(True)
    
    def init_ui(self):
        """Initialisiert UI"""
        layout = QVBoxLayout()
        layout.setContentsMargins(2, 2, 2, 2)
        
        # Adressleiste
        addr_layout = QHBoxLayout()
        
        self.path_input = QLineEdit()
        self.path_input.returnPressed.connect(self.navigate_to_path)
        addr_layout.addWidget(self.path_input)
        
        up_btn = QPushButton("↑")
        up_btn.setMaximumWidth(35)
        up_btn.setToolTip("Hoch (Backspace)")
        up_btn.clicked.connect(self.navigate_up)
        addr_layout.addWidget(up_btn)
        
        refresh_btn = QPushButton("⟳")
        refresh_btn.setMaximumWidth(35)
        refresh_btn.setToolTip("Aktualisieren (F2)")
        refresh_btn.clicked.connect(self.refresh)
        addr_layout.addWidget(refresh_btn)
        
        layout.addLayout(addr_layout)
        
        # File Tree
        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderLabels(["Name", "Größe", "Datum"])
        self.file_tree.setColumnWidth(0, 250)
        self.file_tree.setColumnWidth(1, 80)
        self.file_tree.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection)
        self.file_tree.itemDoubleClicked.connect(self.on_double_click)
        self.file_tree.itemSelectionChanged.connect(self.on_selection_changed)
        self.file_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.file_tree.customContextMenuRequested.connect(self.show_context_menu)
        self.file_tree.setDragEnabled(True)
        self.file_tree.setDragDropMode(QTreeWidget.DragDropMode.DragDrop)
        
        layout.addWidget(self.file_tree)
        
        # Info-Label
        self.info_label = QLabel("Bereit")
        self.info_label.setMaximumHeight(20)
        layout.addWidget(self.info_label)
        
        self.setLayout(layout)
    
    def connect_local(self, path=None):
        """Verbindet mit lokalem FS"""
        self.connection = LocalFileSystem()
        self.connection_type = "LOCAL"
        self.connection.connect(path or str(Path.home()))
        self.current_path = self.connection.current_path
        self.refresh()
        return True
    
    def connect_sftp(self, host, username, password, port=22):
        """Verbindet mit SFTP"""
        self.connection = SFTPConnection()
        if self.connection.connect(host, username, password, port=port):
            self.connection_type = "SFTP"
            self.current_path = "/"
            self.refresh()
            return True
        return False
    
    def connect_ftp(self, host, username, password, port=21):
        """Verbindet mit FTP"""
        self.connection = FTPConnection()
        if self.connection.connect(host, username, password, port=port):
            self.connection_type = "FTP"
            self.current_path = "/"
            self.refresh()
            return True
        return False
    
    def disconnect(self):
        """Trennt Verbindung"""
        if self.connection:
            self.connection.disconnect()
    
    def refresh(self):
        """Aktualisiert Dateiliste"""
        if not self.connection:
            return
        
        self.file_tree.clear()
        self.path_input.setText(self.current_path)
        self.path_changed.emit(self.current_path)
        
        items = self.connection.list_directory(self.current_path)
        
        if not items:
            self.info_label.setText("Leer oder keine Berechtigung")
            return
        
        for item in items:
            tree_item = QTreeWidgetItem()
            
            # Icon
            icon = "📁" if item['is_dir'] else "📄"
            tree_item.setText(0, f"{icon} {item['name']}")
            
            # Größe
            if not item['is_dir']:
                tree_item.setText(1, self.format_size(item['size']))
            else:
                tree_item.setText(1, "<DIR>")
            
            # Datum
            tree_item.setText(2, item['modified'].strftime("%d.%m.%y %H:%M"))
            
            # Speichere Item-Data
            tree_item.setData(0, Qt.ItemDataRole.UserRole, item)
            
            self.file_tree.addTopLevelItem(tree_item)
        
        self.info_label.setText(f"{len(items)} Elemente")
    
    def format_size(self, size):
        """Formatiert Dateigröße"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}PB"
    
    def navigate_to_path(self):
        """Navigiert zu Pfad"""
        path = self.path_input.text()
        if path:
            self.current_path = path
            self.refresh()
    
    def navigate_up(self):
        """Eine Ebene hoch"""
        if self.current_path in ['/', '']:
            return
        
        parent = str(Path(self.current_path).parent)
        if parent:
            self.current_path = parent
            self.refresh()
    
    def on_double_click(self, item, column):
        """Doppelklick auf Item"""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        
        if data and data['is_dir']:
            # In Verzeichnis wechseln
            if self.connection_type == "LOCAL":
                self.current_path = data.get('path', 
                    str(Path(self.current_path) / data['name']))
            else:
                if self.current_path.endswith('/'):
                    self.current_path = self.current_path + data['name']
                else:
                    self.current_path = self.current_path + '/' + data['name']
            
            self.refresh()
    
    def on_selection_changed(self):
        """Selection geändert"""
        items = []
        for item in self.file_tree.selectedItems():
            data = item.data(0, Qt.ItemDataRole.UserRole)
            if data:
                items.append(data)
        
        self.selected_items = items
        self.selection_changed.emit(items)
    
    def get_selected_items(self):
        """Gibt ausgewählte Items zurück"""
        return self.selected_items
    
    def get_full_path(self, item_name):
        """Gibt vollständigen Pfad zurück"""
        if self.connection_type == "LOCAL":
            return str(Path(self.current_path) / item_name)
        else:
            if self.current_path.endswith('/'):
                return self.current_path + item_name
            else:
                return self.current_path + '/' + item_name
    
    def show_context_menu(self, position):
        """Zeigt Kontextmenü"""
        menu = QMenu()
        
        if self.file_tree.selectedItems():
            menu.addAction("F5 - Kopieren", self.copy_selected)
            menu.addAction("F6 - Verschieben", self.move_selected)
            menu.addSeparator()
            menu.addAction("F8 - Löschen", self.delete_selected)
        
        menu.addSeparator()
        menu.addAction("F7 - Neuer Ordner", self.create_directory)
        menu.addAction("F2 - Aktualisieren", self.refresh)
        
        menu.exec(self.file_tree.viewport().mapToGlobal(position))
    
    def copy_selected(self):
        """Kopiert ausgewählte Items"""
        # Signal an Commander
        pass
    
    def move_selected(self):
        """Verschiebt ausgewählte Items"""
        # Signal an Commander
        pass
    
    def delete_selected(self):
        """Löscht ausgewählte Items"""
        items = self.get_selected_items()
        if not items:
            return
        
        names = [item['name'] for item in items]
        reply = QMessageBox.question(
            self,
            "Löschen bestätigen",
            f"{len(items)} Element(e) löschen?\n\n" + "\n".join(names[:5]),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            for item in items:
                path = self.get_full_path(item['name'])
                if item['is_dir']:
                    self.connection.delete_directory(path)
                else:
                    self.connection.delete_file(path)
            
            self.refresh()
    
    def create_directory(self):
        """Erstellt neuen Ordner"""
        name, ok = QInputDialog.getText(
            self, "Neuer Ordner", "Ordnername:"
        )
        
        if ok and name:
            path = self.get_full_path(name)
            if self.connection.create_directory(path):
                self.refresh()
                QMessageBox.information(self, "Erfolg", "Ordner erstellt")
            else:
                QMessageBox.critical(self, "Fehler", "Konnte Ordner nicht erstellen")
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        """Drag Enter"""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event: QDropEvent):
        """Drop Event"""
        # Handle Drop
        urls = event.mimeData().urls()
        for url in urls:
            path = url.toLocalFile()
            # Kopiere Datei hier hin
            print(f"Drop: {path} -> {self.current_path}")


class DualPaneCommander(QWidget):
    """Dual-Pane Commander Widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.left_panel = None
        self.right_panel = None
        self.active_panel = None
        
        self.init_ui()
        self.setup_shortcuts()
    
    def init_ui(self):
        """Initialisiert UI"""
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Splitter für zwei Panels
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Linkes Panel
        self.left_panel = FilePanel()
        self.left_panel.connect_local()
        splitter.addWidget(self.left_panel)
        
        # Rechtes Panel
        self.right_panel = FilePanel()
        self.right_panel.connect_local()
        splitter.addWidget(self.right_panel)
        
        # Gleiche Größe
        splitter.setSizes([500, 500])
        
        layout.addWidget(splitter)
        
        # F-Key Leiste
        fkey_layout = QHBoxLayout()
        
        f_keys = [
            ("F5", "Kopieren", self.copy_files),
            ("F6", "Verschieben", self.move_files),
            ("F7", "Ordner", self.create_directory),
            ("F8", "Löschen", self.delete_files),
        ]
        
        for key, label, func in f_keys:
            btn = QPushButton(f"{key} {label}")
            btn.clicked.connect(func)
            fkey_layout.addWidget(btn)
        
        layout.addLayout(fkey_layout)
        
        self.setLayout(layout)
        
        # Setze linkes Panel als aktiv
        self.active_panel = self.left_panel
    
    def setup_shortcuts(self):
        """Richtet Tastenkürzel ein"""
        QShortcut(Qt.Key.Key_F5, self, self.copy_files)
        QShortcut(Qt.Key.Key_F6, self, self.move_files)
        QShortcut(Qt.Key.Key_F7, self, self.create_directory)
        QShortcut(Qt.Key.Key_F8, self, self.delete_files)
        QShortcut(Qt.Key.Key_F2, self, lambda: self.active_panel.refresh() if self.active_panel else None)
        QShortcut(Qt.Key.Key_Tab, self, self.switch_panel)
    
    def switch_panel(self):
        """Wechselt aktives Panel"""
        if self.active_panel == self.left_panel:
            self.active_panel = self.right_panel
        else:
            self.active_panel = self.left_panel
    
    def get_target_panel(self):
        """Gibt Ziel-Panel zurück"""
        if self.active_panel == self.left_panel:
            return self.right_panel
        return self.left_panel
    
    def copy_files(self):
        """Kopiert Dateien F5"""
        source_panel = self.active_panel
        target_panel = self.get_target_panel()
        
        items = source_panel.get_selected_items()
        if not items:
            QMessageBox.warning(self, "Keine Auswahl", "Keine Dateien ausgewählt!")
            return
        
        # Zeige Copy-Dialog
        self.show_copy_dialog(source_panel, target_panel, items, move=False)
    
    def move_files(self):
        """Verschiebt Dateien F6"""
        source_panel = self.active_panel
        target_panel = self.get_target_panel()
        
        items = source_panel.get_selected_items()
        if not items:
            QMessageBox.warning(self, "Keine Auswahl", "Keine Dateien ausgewählt!")
            return
        
        # Zeige Move-Dialog
        self.show_copy_dialog(source_panel, target_panel, items, move=True)
    
    def show_copy_dialog(self, source, target, items, move=False):
        """Zeigt Copy/Move Dialog mit Progress"""
        operation = "Verschieben" if move else "Kopieren"
        
        progress = QProgressDialog(
            f"{operation} von {len(items)} Datei(en)...",
            "Abbrechen",
            0,
            len(items),
            self
        )
        progress.setWindowTitle(operation)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        
        for i, item in enumerate(items):
            if progress.wasCanceled():
                break
            
            progress.setLabelText(f"{operation}: {item['name']}")
            progress.setValue(i)
            
            # Kopiere/Verschiebe Datei
            source_path = source.get_full_path(item['name'])
            target_path = target.get_full_path(item['name'])
            
            try:
                if source.connection_type == "LOCAL" and target.connection_type == "LOCAL":
                    # Lokal zu Lokal
                    import shutil
                    if item['is_dir']:
                        shutil.copytree(source_path, target_path)
                    else:
                        shutil.copy2(source_path, target_path)
                    
                    if move:
                        if item['is_dir']:
                            shutil.rmtree(source_path)
                        else:
                            import os
                            os.remove(source_path)
                else:
                    # Download/Upload
                    if not item['is_dir']:
                        # Temp-Datei
                        import tempfile
                        with tempfile.NamedTemporaryFile(delete=False) as tmp:
                            tmp_path = tmp.name
                        
                        # Download
                        source.connection.download_file(source_path, tmp_path)
                        # Upload
                        target.connection.upload_file(tmp_path, target_path)
                        
                        # Lösche temp
                        import os
                        os.unlink(tmp_path)
                        
                        if move:
                            source.connection.delete_file(source_path)
            
            except Exception as e:
                QMessageBox.critical(self, "Fehler", f"Fehler bei {item['name']}: {e}")
        
        progress.setValue(len(items))
        
        # Refresh both panels
        source.refresh()
        target.refresh()
        
        QMessageBox.information(self, "Fertig", f"{operation} abgeschlossen!")
    
    def delete_files(self):
        """Löscht Dateien F8"""
        if self.active_panel:
            self.active_panel.delete_selected()
    
    def create_directory(self):
        """Erstellt Ordner F7"""
        if self.active_panel:
            self.active_panel.create_directory()
