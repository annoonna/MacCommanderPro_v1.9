"""
Konfigurationsmodul für MacCommander Pro
"""

import os
import json
from pathlib import Path

class Config:
    """Zentrale Konfigurationsverwaltung"""
    
    def __init__(self):
        self.app_name = "MacCommander Pro"
        self.version = "0.1.0"
        
        # Pfade
        self.home_dir = Path.home()
        self.config_dir = self.home_dir / ".maccommander"
        self.config_file = self.config_dir / "config.json"
        self.connections_file = self.config_dir / "connections.json"
        self.themes_dir = self.config_dir / "themes"
        
        # Erstelle Verzeichnisse
        self.config_dir.mkdir(exist_ok=True)
        self.themes_dir.mkdir(exist_ok=True)
        
        # Standardkonfiguration
        self.default_config = {
            "theme": "dark",
            "theme_variant": "default",
            "language": "de",
            "window": {
                "width": 1200,
                "height": 800,
                "maximized": False
            },
            "file_browser": {
                "show_hidden": False,
                "dual_pane": True,
                "icon_size": 24
            },
            "connections": {
                "remember_passwords": False,
                "auto_reconnect": True,
                "timeout": 30
            }
        }
        
        # Lade Konfiguration
        self.config = self.load_config()
    
    def load_config(self):
        """Lädt Konfiguration aus Datei"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    # Merge mit Defaults
                    return {**self.default_config, **loaded}
            except Exception as e:
                print(f"Fehler beim Laden der Config: {e}")
        
        return self.default_config.copy()
    
    def save_config(self):
        """Speichert Konfiguration in Datei"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4)
            return True
        except Exception as e:
            print(f"Fehler beim Speichern der Config: {e}")
            return False
    
    def get(self, key, default=None):
        """Holt Konfigurationswert"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key, value):
        """Setzt Konfigurationswert"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        self.save_config()

# Globale Config-Instanz
_config = None

def get_config():
    """Holt globale Config-Instanz"""
    global _config
    if _config is None:
        _config = Config()
    return _config
