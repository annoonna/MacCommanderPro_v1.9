#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Universal Mount Manager
Unified interface for mounting ALL protocols (SFTP, FTP, SMB, WebDAV)
"""

import os
import subprocess
from typing import Optional, Dict, Any, List
from enum import Enum
from pathlib import Path


class MountProtocol(Enum):
    """Supported mount protocols"""
    SFTP = "sftp"
    FTP = "ftp"
    SMB = "smb"
    WEBDAV = "webdav"


class UniversalMountManager:
    """
    Universal Mount Manager for ALL protocols
    
    This is the CORE feature - mount anything as macOS volume!
    """
    
    def __init__(self):
        self.mounted_volumes: Dict[str, Dict[str, Any]] = {}
        self._check_dependencies()
        
        # Get logger if available
        try:
            from src.utils.logger import get_logger
            self.logger = get_logger()
        except:
            self.logger = None
    
    def _log(self, level, message):
        """Log message if logger available"""
        if self.logger:
            if level == 'info':
                self.logger.info(message)
            elif level == 'error':
                self.logger.error(message)
            elif level == 'debug':
                self.logger.debug(message)
        print(message)
    
    def _check_dependencies(self):
        """Check if required tools are installed"""
        self.sshfs_available = self._command_exists('sshfs')
        self.curlftpfs_available = self._command_exists('curlftpfs')
        self.mount_smbfs_available = True  # Built into macOS
        self.mount_webdav_available = True  # Built into macOS
        
        if not self.sshfs_available:
            print("⚠️  SSHFS not available. Install with: brew install macfuse sshfs")
        
        if not self.curlftpfs_available:
            print("💡 CurlFTPFS not available. FTP mount will use alternative method")
    
    def _command_exists(self, command: str) -> bool:
        """Check if command exists in PATH"""
        try:
            subprocess.run(['which', command], capture_output=True, check=True)
            return True
        except:
            return False
    
    def mount_sftp(self, host: str, username: str, password: str = "",
                   ssh_key: str = "", port: int = 22,
                   remote_path: str = "/", mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount SFTP as macOS volume using SSHFS
        
        Args:
            host: Server hostname
            username: SSH username
            password: SSH password (optional if using key)
            ssh_key: Path to SSH private key
            port: SSH port
            remote_path: Remote directory to mount
            mount_point: Local mount point
        
        Returns:
            Mount point path if successful
        """
        if not self.sshfs_available:
            return self._mount_sftp_fallback(host, username, password, port, remote_path, mount_point)
        
        try:
            # Create mount point in user's home directory (no sudo needed!)
            if not mount_point:
                mounts_dir = Path.home() / "MacCommanderMounts"
                mounts_dir.mkdir(exist_ok=True)
                mount_point = str(mounts_dir / f"SFTP_{host.replace('.', '_')}")
            
            # Create specific mount point
            os.makedirs(mount_point, exist_ok=True)
            self._log('info', f"📁 Mount-Point erstellt: {mount_point}")
            
            # Build SSHFS command
            cmd = [
                'sshfs',
                f'{username}@{host}:{remote_path}',
                mount_point,
                '-p', str(port),
                '-o', 'auto_cache,reconnect,defer_permissions,noappledouble',
                '-o', f'volname=SFTP_{host}'
            ]
            
            # Add authentication - PRIORITÄT: Password > SSH Key
            # Warum? Password ist einfacher und funktioniert immer wenn richtig
            if password:
                # Use sshpass if available, otherwise use expect
                sshpass_available = self._command_exists('sshpass')
                
                if sshpass_available:
                    # Use sshpass - AM EINFACHSTEN!
                    cmd = ['sshpass', '-p', password] + cmd
                    cmd.extend(['-o', 'StrictHostKeyChecking=no'])
                    cmd.extend(['-o', 'PreferredAuthentications=password'])
                    
                    self._log('info', f"🔐 Mounting with password (sshpass)")
                    result = subprocess.run(cmd, capture_output=True, timeout=30)
                    
                    if result.returncode == 0:
                        self._register_mount(mount_point, MountProtocol.SFTP, {
                            'host': host,
                            'username': username,
                            'port': port,
                            'remote_path': remote_path
                        })
                        
                        subprocess.run(['open', mount_point])
                        self._log('info', f"✅ Mounted at: {mount_point}")
                        return mount_point
                    else:
                        error_msg = result.stderr.decode()
                        self._log('error', f"❌ SSHFS mount failed: {error_msg}")
                        return None
                else:
                    # Fallback: Create expect script
                    expect_script = f"""#!/usr/bin/expect -f
set timeout 30
spawn sshfs {username}@{host}:{remote_path} {mount_point} -p {port} -o auto_cache,reconnect,defer_permissions,noappledouble,StrictHostKeyChecking=no -o volname=SFTP_{host}
expect {{
    "password:" {{
        send "{password}\\r"
        expect eof
    }}
    "Password:" {{
        send "{password}\\r"
        expect eof
    }}
    timeout {{
        exit 1
    }}
}}
"""
                    
                    # Write expect script
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.exp', delete=False) as f:
                        f.write(expect_script)
                        expect_file = f.name
                    
                    os.chmod(expect_file, 0o700)
                    
                    self._log('info', f"🔐 Mounting with password (expect)")
                    result = subprocess.run(['expect', expect_file], capture_output=True, timeout=45)
                    
                    os.unlink(expect_file)
                    
                    if result.returncode == 0:
                        self._register_mount(mount_point, MountProtocol.SFTP, {
                            'host': host,
                            'username': username,
                            'port': port,
                            'remote_path': remote_path
                        })
                        
                        subprocess.run(['open', mount_point])
                        self._log('info', f"✅ Mounted at: {mount_point}")
                        return mount_point
                    else:
                        error_msg = result.stderr.decode()
                        self._log('error', f"❌ SSHFS mount failed: {error_msg}")
                        return None
                        
            elif ssh_key:
                # Remove .pub if accidentally added (public key instead of private)
                if ssh_key.endswith('.pub'):
                    ssh_key = ssh_key[:-4]  # Remove .pub
                    self._log('info', f"⚠️  Korrigiere SSH Key: .pub entfernt → {ssh_key}")
                
                cmd.extend(['-o', f'IdentityFile={ssh_key}'])
                cmd.extend(['-o', 'StrictHostKeyChecking=no'])
                cmd.extend(['-o', 'PasswordAuthentication=no'])  # Don't ask for password!
                
                self._log('info', f"🔐 Mounting with SSH key: {ssh_key}")
                result = subprocess.run(cmd, capture_output=True, timeout=30)
                
                if result.returncode == 0:
                    self._register_mount(mount_point, MountProtocol.SFTP, {
                        'host': host,
                        'username': username,
                        'port': port,
                        'remote_path': remote_path
                    })
                    
                    subprocess.run(['open', mount_point])
                    self._log('info', f"✅ Mounted at: {mount_point}")
                    return mount_point
                else:
                    self._log('error', f"❌ SSHFS mount failed: {result.stderr.decode()}")
                    return None
                    
            else:
                # No password, no key - will prompt
                cmd.extend(['-o', 'StrictHostKeyChecking=no'])
                
                self._log('info', f"🔐 Mounting (will prompt for password)")
                result = subprocess.run(cmd, capture_output=True, timeout=30)
                
                if result.returncode == 0:
                    self._register_mount(mount_point, MountProtocol.SFTP, {
                        'host': host,
                        'username': username,
                        'port': port,
                        'remote_path': remote_path
                    })
                    
                    subprocess.run(['open', mount_point])
                    self._log('info', f"✅ Mounted at: {mount_point}")
                    return mount_point
                else:
                    self._log('error', f"❌ SSHFS mount failed: {result.stderr.decode()}")
                    return None
            
        except Exception as e:
            print(f"❌ SFTP mount error: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _mount_sftp_fallback(self, host: str, username: str, password: str,
                            port: int, remote_path: str, mount_point: Optional[str]) -> Optional[str]:
        """Fallback SFTP mount method (creates symlink to manual mount)"""
        print("💡 Using fallback SFTP mount method")
        print(f"   Please mount manually: sftp://{username}@{host}:{port}{remote_path}")
        return None
    
    def mount_ftp(self, host: str, username: str, password: str,
                  port: int = 21, use_ssl: bool = False,
                  remote_path: str = "/", mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount FTP as macOS volume
        
        Args:
            host: FTP server hostname
            username: FTP username
            password: FTP password
            port: FTP port
            use_ssl: Use FTPS
            remote_path: Remote directory
            mount_point: Local mount point
        
        Returns:
            Mount point path if successful
        """
        try:
            # Create mount point
            if not mount_point:
                mount_point = f"/Volumes/FTP_{host.replace('.', '_')}"
            
            os.makedirs(mount_point, exist_ok=True)
            
            # Use curlftpfs if available
            if self.curlftpfs_available:
                protocol = "ftps" if use_ssl else "ftp"
                ftp_url = f"{protocol}://{username}:{password}@{host}:{port}{remote_path}"
                
                cmd = [
                    'curlftpfs',
                    ftp_url,
                    mount_point,
                    '-o', 'auto_cache,reconnect',
                    '-o', f'volname=FTP_{host}'
                ]
                
                result = subprocess.run(cmd, capture_output=True, timeout=30)
                
                if result.returncode == 0:
                    self._register_mount(mount_point, MountProtocol.FTP, {
                        'host': host,
                        'username': username,
                        'port': port,
                        'use_ssl': use_ssl
                    })
                    
                    subprocess.run(['open', mount_point])
                    return mount_point
            
            # Fallback: Use Finder's Connect to Server
            print("💡 Using Finder Connect to Server for FTP")
            protocol = "ftps" if use_ssl else "ftp"
            ftp_url = f"{protocol}://{username}:{password}@{host}:{port}{remote_path}"
            
            # Open in Finder
            subprocess.run(['open', ftp_url])
            
            print(f"   FTP URL opened in Finder: {protocol}://{username}@{host}:{port}{remote_path}")
            return None
            
        except Exception as e:
            print(f"❌ FTP mount error: {e}")
            return None
    
    def mount_smb(self, host: str, share: str, username: str, password: str,
                  domain: str = "", mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount SMB/CIFS as macOS volume
        
        Args:
            host: Server hostname
            share: Share name
            username: Username
            password: Password
            domain: Windows domain
            mount_point: Local mount point
        
        Returns:
            Mount point path if successful
        """
        try:
            # Create mount point
            if not mount_point:
                mount_point = f"/Volumes/{share}"
            
            os.makedirs(mount_point, exist_ok=True)
            
            # Build SMB URL
            if domain:
                smb_url = f"smb://{domain};{username}:{password}@{host}/{share}"
            else:
                smb_url = f"smb://{username}:{password}@{host}/{share}"
            
            # Mount
            cmd = ['mount', '-t', 'smbfs', smb_url, mount_point]
            result = subprocess.run(cmd, capture_output=True, timeout=30)
            
            if result.returncode == 0:
                self._register_mount(mount_point, MountProtocol.SMB, {
                    'host': host,
                    'share': share,
                    'username': username,
                    'domain': domain
                })
                
                subprocess.run(['open', mount_point])
                return mount_point
            
            print(f"❌ SMB mount failed: {result.stderr.decode()}")
            return None
            
        except Exception as e:
            print(f"❌ SMB mount error: {e}")
            return None
    
    def mount_webdav(self, url: str, username: str, password: str,
                     use_ssl: bool = True, mount_point: Optional[str] = None) -> Optional[str]:
        """
        Mount WebDAV as macOS volume
        
        Args:
            url: WebDAV server URL
            username: Username
            password: Password
            use_ssl: Use HTTPS
            mount_point: Local mount point
        
        Returns:
            Mount point path if successful
        """
        try:
            # Build full URL
            protocol = "https" if use_ssl else "http"
            if not url.startswith('http'):
                url = f"{protocol}://{url}"
            
            # Create mount point
            if not mount_point:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                host_name = parsed.netloc.replace('.', '_').replace(':', '_')
                mount_point = f"/Volumes/WebDAV_{host_name}"
            
            os.makedirs(mount_point, exist_ok=True)
            
            # Encode credentials in URL
            from urllib.parse import quote
            encoded_user = quote(username, safe='')
            encoded_pass = quote(password, safe='')
            
            from urllib.parse import urlparse
            parsed = urlparse(url)
            dav_url = f"{parsed.scheme}://{encoded_user}:{encoded_pass}@{parsed.netloc}{parsed.path}"
            
            # Mount
            cmd = ['mount', '-t', 'webdav', dav_url, mount_point]
            result = subprocess.run(cmd, capture_output=True, timeout=30)
            
            if result.returncode == 0:
                self._register_mount(mount_point, MountProtocol.WEBDAV, {
                    'url': url,
                    'username': username,
                    'use_ssl': use_ssl
                })
                
                subprocess.run(['open', mount_point])
                return mount_point
            
            print(f"❌ WebDAV mount failed: {result.stderr.decode()}")
            return None
            
        except Exception as e:
            print(f"❌ WebDAV mount error: {e}")
            return None
    
    def unmount(self, mount_point: str) -> bool:
        """Unmount any volume"""
        try:
            result = subprocess.run(
                ['umount', mount_point],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                self._unregister_mount(mount_point)
                
                # Remove mount point directory
                try:
                    os.rmdir(mount_point)
                except:
                    pass
                
                return True
            
            # Try force unmount
            result = subprocess.run(
                ['umount', '-f', mount_point],
                capture_output=True,
                timeout=10
            )
            
            if result.returncode == 0:
                self._unregister_mount(mount_point)
                try:
                    os.rmdir(mount_point)
                except:
                    pass
                return True
            
            return False
            
        except Exception as e:
            print(f"❌ Unmount error: {e}")
            return False
    
    def _register_mount(self, mount_point: str, protocol: MountProtocol, info: Dict[str, Any]):
        """Register a mounted volume"""
        self.mounted_volumes[mount_point] = {
            'protocol': protocol,
            'info': info,
            'mounted_at': __import__('datetime').datetime.now()
        }
    
    def _unregister_mount(self, mount_point: str):
        """Unregister a mounted volume"""
        if mount_point in self.mounted_volumes:
            del self.mounted_volumes[mount_point]
    
    def get_mounted_volumes(self) -> Dict[str, Dict[str, Any]]:
        """Get all mounted volumes"""
        return self.mounted_volumes.copy()
    
    def is_mounted(self, mount_point: str) -> bool:
        """Check if volume is mounted"""
        return mount_point in self.mounted_volumes and os.path.ismount(mount_point)
    
    def get_all_mounts(self) -> List[str]:
        """Get all active mount points"""
        try:
            result = subprocess.run(['mount'], capture_output=True)
            mounts = []
            
            for line in result.stdout.decode().split('\n'):
                if '/Volumes/' in line:
                    parts = line.split(' on ')
                    if len(parts) >= 2:
                        mount_point = parts[1].split(' (')[0]
                        mounts.append(mount_point)
            
            return mounts
        except:
            return []
