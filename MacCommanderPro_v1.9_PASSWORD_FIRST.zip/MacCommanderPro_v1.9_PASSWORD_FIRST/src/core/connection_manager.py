#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Connection Manager
Manages all protocol connections with real-time status monitoring
"""

import time
import threading
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class ConnectionStatus(Enum):
    """Connection status states with Neon colors"""
    OFFLINE = ("offline", "🔴", "#FF0000")
    CONNECTING = ("connecting", "🟡", "#FFFF00")
    CONNECTED = ("connected", "🟢", "#00FF00")
    ERROR = ("error", "🔴", "#FF0000")
    DISCONNECTING = ("disconnecting", "🟡", "#FFA500")


@dataclass
class ConnectionStats:
    """Real-time connection statistics"""
    upload_speed: float = 0.0  # MB/s
    download_speed: float = 0.0  # MB/s
    latency: int = 0  # ms
    uptime: int = 0  # seconds
    bytes_sent: int = 0
    bytes_received: int = 0
    last_activity: Optional[datetime] = None


@dataclass
class ConnectionProfile:
    """Saved connection profile"""
    name: str
    protocol: str  # sftp, ftp, smb, webdav
    host: str
    port: int
    username: str
    password: str = ""  # Optional - can use SSH keys
    ssh_key: str = ""
    use_ssl: bool = False
    auto_mount: bool = False
    mount_point: str = ""
    
    def to_dict(self) -> dict:
        """Convert to dictionary for saving"""
        return {
            'name': self.name,
            'protocol': self.protocol,
            'host': self.host,
            'port': self.port,
            'username': self.username,
            'use_ssl': self.use_ssl,
            'auto_mount': self.auto_mount,
            'mount_point': self.mount_point
        }


class Connection:
    """Single connection instance with monitoring"""
    
    def __init__(self, profile: ConnectionProfile):
        self.profile = profile
        self.status = ConnectionStatus.OFFLINE
        self.stats = ConnectionStats()
        self.client = None
        self.mount_path: Optional[str] = None
        self.is_mounted = False
        
        # Monitoring
        self._monitor_thread: Optional[threading.Thread] = None
        self._monitoring = False
        self._status_callbacks: List[Callable] = []
        self._connect_time: Optional[datetime] = None
    
    def add_status_callback(self, callback: Callable):
        """Add callback for status changes"""
        self._status_callbacks.append(callback)
    
    def _notify_status_change(self):
        """Notify all callbacks of status change"""
        for callback in self._status_callbacks:
            try:
                callback(self.status, self.stats)
            except Exception as e:
                print(f"❌ Status callback error: {e}")
    
    def set_status(self, status: ConnectionStatus):
        """Update connection status"""
        self.status = status
        self._notify_status_change()
    
    def start_monitoring(self):
        """Start real-time connection monitoring"""
        if self._monitoring:
            return
        
        self._monitoring = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop connection monitoring"""
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
    
    def _monitor_loop(self):
        """Monitor connection health and statistics"""
        while self._monitoring:
            try:
                if self.status == ConnectionStatus.CONNECTED and self.client:
                    # Update uptime
                    if self._connect_time:
                        self.stats.uptime = int((datetime.now() - self._connect_time).total_seconds())
                    
                    # Test connection with ping
                    start_time = time.time()
                    is_alive = self._test_connection()
                    latency = int((time.time() - start_time) * 1000)
                    
                    if is_alive:
                        self.stats.latency = latency
                        self.stats.last_activity = datetime.now()
                    else:
                        # Connection lost
                        self.set_status(ConnectionStatus.ERROR)
                    
                    self._notify_status_change()
                
                time.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                print(f"❌ Monitor error: {e}")
                time.sleep(5)
    
    def _test_connection(self) -> bool:
        """Test if connection is still alive"""
        try:
            if self.profile.protocol == 'sftp':
                # Try to list current directory
                if hasattr(self.client, 'listdir'):
                    self.client.listdir('.')
                    return True
            elif self.profile.protocol == 'ftp':
                # Try PWD command
                if hasattr(self.client, 'pwd'):
                    self.client.pwd()
                    return True
            return False
        except:
            return False
    
    def update_transfer_stats(self, bytes_sent: int = 0, bytes_received: int = 0):
        """Update transfer statistics"""
        self.stats.bytes_sent += bytes_sent
        self.stats.bytes_received += bytes_received
        self.stats.last_activity = datetime.now()
        
        # Calculate speeds (simplified - in real implementation use rolling average)
        if bytes_sent > 0:
            self.stats.upload_speed = bytes_sent / (1024 * 1024)  # MB/s
        if bytes_received > 0:
            self.stats.download_speed = bytes_received / (1024 * 1024)  # MB/s


class ConnectionManager:
    """Manages all connections with profiles and monitoring"""
    
    def __init__(self):
        self.connections: Dict[str, Connection] = {}
        self.profiles: Dict[str, ConnectionProfile] = {}
        self._lock = threading.Lock()
    
    def add_profile(self, profile: ConnectionProfile) -> bool:
        """Add a new connection profile"""
        with self._lock:
            if profile.name in self.profiles:
                return False
            self.profiles[profile.name] = profile
            return True
    
    def remove_profile(self, name: str) -> bool:
        """Remove a connection profile"""
        with self._lock:
            if name in self.connections:
                self.disconnect(name)
            if name in self.profiles:
                del self.profiles[name]
                return True
            return False
    
    def get_profile(self, name: str) -> Optional[ConnectionProfile]:
        """Get connection profile by name"""
        return self.profiles.get(name)
    
    def list_profiles(self) -> List[ConnectionProfile]:
        """List all connection profiles"""
        return list(self.profiles.values())
    
    def connect(self, profile_name: str) -> bool:
        """Connect using a saved profile"""
        profile = self.profiles.get(profile_name)
        if not profile:
            return False
        
        # Create new connection
        connection = Connection(profile)
        connection.set_status(ConnectionStatus.CONNECTING)
        
        # Store connection
        with self._lock:
            self.connections[profile_name] = connection
        
        # Start monitoring
        connection.start_monitoring()
        
        return True
    
    def disconnect(self, name: str) -> bool:
        """Disconnect a connection"""
        with self._lock:
            connection = self.connections.get(name)
            if not connection:
                return False
            
            connection.set_status(ConnectionStatus.DISCONNECTING)
            connection.stop_monitoring()
            
            # Unmount if mounted
            if connection.is_mounted:
                self.unmount(name)
            
            # Close client
            if connection.client:
                try:
                    if hasattr(connection.client, 'close'):
                        connection.client.close()
                except:
                    pass
            
            connection.set_status(ConnectionStatus.OFFLINE)
            del self.connections[name]
            
            return True
    
    def get_connection(self, name: str) -> Optional[Connection]:
        """Get active connection by name"""
        return self.connections.get(name)
    
    def list_connections(self) -> List[Connection]:
        """List all active connections"""
        return list(self.connections.values())
    
    def mount(self, name: str, mount_point: Optional[str] = None) -> bool:
        """Mount connection as macOS volume"""
        connection = self.connections.get(name)
        if not connection or connection.status != ConnectionStatus.CONNECTED:
            return False
        
        # Will be implemented by protocol-specific handlers
        return False
    
    def unmount(self, name: str) -> bool:
        """Unmount connection"""
        connection = self.connections.get(name)
        if not connection or not connection.is_mounted:
            return False
        
        # Will be implemented by protocol-specific handlers
        return False
    
    def get_status(self, name: str) -> Optional[ConnectionStatus]:
        """Get connection status"""
        connection = self.connections.get(name)
        return connection.status if connection else None
    
    def get_stats(self, name: str) -> Optional[ConnectionStats]:
        """Get connection statistics"""
        connection = self.connections.get(name)
        return connection.stats if connection else None
