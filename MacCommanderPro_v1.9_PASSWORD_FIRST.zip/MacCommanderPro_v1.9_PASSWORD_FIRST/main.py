#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Main Entry Point
Wrapper for maccommander_pro.py
"""

# Simply import and run
from maccommander_pro import *

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    window = MacCommanderProProfessional()
    window.show()
    sys.exit(app.exec())
