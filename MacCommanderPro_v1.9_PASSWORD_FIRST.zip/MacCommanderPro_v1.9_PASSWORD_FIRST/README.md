# 🚀 MacCommander Pro PROFESSIONAL

**The Ultimate Multi-Protocol File Manager for macOS**

[![Version](https://img.shields.io/badge/version-1.0-blue.svg)](https://github.com/maccommander/pro)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![macOS](https://img.shields.io/badge/macOS-11%2B-orange.svg)](https://www.apple.com/macos)

---

## ✨ Features

### 🔗 Multi-Protocol Support
- **SFTP/SSH** - Secure file transfer with key-based authentication
- **FTP/FTPS** - Traditional and secure FTP
- **SMB/CIFS** - Windows/Samba network shares
- **WebDAV** - Cloud storage (Nextcloud, ownCloud, Box.com, etc.)

### 💾 Universal Mount System
Mount **ANY** protocol as a native macOS volume!
- Shows in Finder
- Works with all apps
- Drag & drop support
- Full read/write access

### 🟢 Real-time Connection Status
Beautiful NEON status display showing:
- 🔴 Offline / 🟡 Connecting / 🟢 Connected
- Upload/Download speeds
- Latency monitoring
- Connection uptime
- Transfer statistics

### 📡 Connection Manager
- Save unlimited connection profiles
- Quick connect from saved profiles
- Edit and organize connections
- Auto-mount on connect
- Test connections before mounting

### 🎨 Professional UI
- Clean, modern interface
- Dark theme support
- Keyboard shortcuts
- Context menus
- Status dock

---

## 📋 Requirements

### System Requirements
- **macOS** 11 (Big Sur) or later
- **Python** 3.8 or later
- **4GB RAM** minimum (8GB recommended)

### Optional Dependencies
For full functionality:
- **Homebrew** - Package manager for macOS
- **macFUSE** - For SFTP mounting
- **sshfs-mac** - SFTP filesystem driver

---

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or extract the archive
cd MacCommanderPro_Professional

# Run the installer
python3 install.py
```

The installer will:
- ✅ Check Python version
- ✅ Install Python packages (PyQt6, Paramiko)
- ✅ Optionally install system dependencies (macFUSE, sshfs)
- ✅ Create configuration directory

### 2. Launch

```bash
python3 maccommander_pro.py
```

### 3. Create Your First Connection

1. Click **"📡 Connection Manager"**
2. Click **"➕ New"**
3. Enter connection details:
   - Profile Name: `My Server`
   - Protocol: `SFTP`
   - Host: `server.example.com`
   - Username: `your_username`
   - Password: `your_password` (or use SSH key)
4. Click **"Test Connection"**
5. Click **"OK"** to save

### 4. Connect & Mount

1. Select your profile in Connection Manager
2. Click **"🔗 Connect"**
3. Wait for 🟢 **Connected!** status
4. Click **"💾 Mount"**
5. Volume appears in Finder!

---

## 📖 Usage Guide

### Connection Profiles

#### Creating a Profile
- **File → Connect** or **Ctrl+N**
- Fill in connection details
- Save profile for later use

#### Protocol-Specific Settings

**SFTP:**
- Port: 22 (default)
- Authentication: Password or SSH key
- SSH Key path: `~/.ssh/id_rsa`

**FTP/FTPS:**
- Port: 21 (FTP) or 990 (FTPS)
- SSL/TLS: Enable for FTPS

**SMB:**
- Port: 445 (default)
- Share name required
- Optional domain/workgroup

**WebDAV:**
- Port: 443 (HTTPS) or 80 (HTTP)
- Works with Nextcloud, ownCloud, Box.com, etc.
- Full URL path supported

### Mounting Volumes

#### Quick Mount
**Ctrl+M** → Select profile → Auto-mount

#### Manual Mount
1. Connect to server first
2. Click **"💾 Mount Volume"**
3. Choose mount point (optional)
4. Volume appears in `/Volumes/`

#### Mount Options
- Custom mount point
- Auto-mount on connect
- Remote path selection

### Connection Status

The **Neon Status Widget** shows:
- 🔴 **Offline** - Not connected
- 🟡 **Connecting** - Connection in progress
- 🟢 **Connected** - Active and ready

**Live Statistics:**
- 📤 Upload Speed (MB/s)
- 📥 Download Speed (MB/s)
- 📊 Latency (ms)
- ⏱️ Uptime
- 📊 Total transferred

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| **Ctrl+N** | New Connection |
| **Ctrl+M** | Quick Mount |
| **Ctrl+Q** | Quit |

---

## 🔧 Configuration

### Config Directory
`~/.maccommander_pro/`

Contains:
- `profiles.json` - Saved connection profiles
- `settings.json` - Application settings
- `logs/` - Application logs

### Profile Export/Import
Profiles are stored in JSON format and can be:
- Backed up
- Shared between machines
- Version controlled

---

## 🐛 Troubleshooting

### SFTP Mount Not Working

**Problem:** "SSHFS not available"

**Solution:**
```bash
brew install macfuse
brew install gromgit/fuse/sshfs-mac
```

Reboot required after installing macFUSE!

### SMB Connection Failed

**Problem:** Can't connect to Windows share

**Solutions:**
- Check share name is correct
- Verify network connectivity
- Try with/without domain
- Check Windows firewall

### WebDAV Authentication Error

**Problem:** 401 Unauthorized

**Solutions:**
- Verify username/password
- Check URL includes full path
- Try HTTPS instead of HTTP
- Check cloud provider settings

### Mount Point Already Exists

**Problem:** "Mount point already in use"

**Solution:**
```bash
# List mounted volumes
mount | grep /Volumes

# Unmount if needed
umount /Volumes/YourVolume
```

### Performance Issues

**Solutions:**
- Check network speed
- Reduce concurrent transfers
- Check latency in status widget
- Try different mount options

---

## 📚 Advanced Features

### SSH Key Authentication

1. Generate SSH key pair:
```bash
ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
```

2. Copy public key to server:
```bash
ssh-copy-id user@server.example.com
```

3. In profile settings:
   - Leave password empty
   - Set SSH Key: `~/.ssh/id_rsa`

### Custom Mount Points

Instead of `/Volumes/ServerName`, use custom paths:
```
/Volumes/MyWork
/Volumes/BackupDrive
/Volumes/CloudStorage
```

### Auto-Mount on Connect

Enable in profile settings:
- ✅ **Auto-mount on connect**
- Set mount point
- Set remote path

Now connecting automatically mounts the volume!

### Multiple Connections

Connect to multiple servers simultaneously:
- Each gets its own status widget
- Independent mount points
- Separate statistics tracking

---

## 🔒 Security

### Password Storage
- Passwords stored in system keychain (optional)
- Never stored in plain text
- Option to prompt each time

### SSH Keys
- Recommended over passwords
- More secure
- No password needed

### SSL/TLS
- Always enabled by default
- Certificate validation
- Secure transmission

---

## 🆘 Support & Documentation

### Included Documentation
- **README.md** (this file) - Main documentation
- **MOUNT_GUIDE.md** - Detailed mounting guide
- **PROTOCOLS.md** - Protocol-specific details
- **QUICKSTART.md** - Quick reference

### Getting Help
1. Check troubleshooting section
2. Review protocol-specific guides
3. Check application logs in `~/.maccommander_pro/logs/`

---

## 🎯 Tips & Tricks

### Productivity Tips

1. **Save Frequent Connections**
   - Create profiles for all your servers
   - Quick connect with one click

2. **Use Keyboard Shortcuts**
   - Ctrl+N for new connection
   - Ctrl+M for quick mount

3. **Monitor Performance**
   - Watch status widget
   - Check latency
   - Optimize based on stats

4. **Organize Profiles**
   - Use descriptive names
   - Group by project/client
   - Add notes in profile

### Best Practices

1. **Security**
   - Use SSH keys when possible
   - Enable SSL/TLS
   - Don't share passwords

2. **Performance**
   - Check latency before large transfers
   - Use local network when possible
   - Close unused connections

3. **Reliability**
   - Test connections before mounting
   - Monitor connection uptime
   - Have backup profiles

---

## 📊 What's New in PROFESSIONAL Edition

### vs. Standard Edition
✅ **SMB/CIFS Support** - Windows network shares  
✅ **WebDAV Support** - Cloud storage integration  
✅ **Universal Mount System** - Mount all protocols  
✅ **Neon Status Display** - Real-time monitoring  
✅ **Connection Manager** - Save unlimited profiles  
✅ **Auto-Mount** - Automatic mounting  
✅ **Professional UI** - Polished interface  
✅ **Live Statistics** - Speed, latency, uptime  

---

## 🚧 Roadmap

### Planned Features
- [ ] File browser/commander interface
- [ ] Transfer queue management
- [ ] Sync/backup functionality
- [ ] Cloud provider integrations (Dropbox, Google Drive)
- [ ] Encrypted containers
- [ ] Batch operations
- [ ] Custom themes

---

## 📜 License

MIT License - See LICENSE file for details

---

## 🙏 Acknowledgments

Built with:
- **PyQt6** - UI framework
- **Paramiko** - SSH/SFTP library
- **macFUSE** - FUSE for macOS
- **sshfs-mac** - SFTP filesystem

---

## 🎉 Enjoy MacCommander Pro PROFESSIONAL!

**Questions? Issues? Suggestions?**  
Check the docs folder for more detailed guides!

---

**Made with ❤️ for macOS power users** 🚀
