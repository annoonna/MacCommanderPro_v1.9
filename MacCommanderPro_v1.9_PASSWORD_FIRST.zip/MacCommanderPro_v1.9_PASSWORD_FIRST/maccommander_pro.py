#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL Edition
The Ultimate Multi-Protocol File Manager for macOS

Features:
- Multi-Protocol Support (SFTP, FTP, SMB, WebDAV)
- Universal Mount System (mount ANY protocol as macOS volume!)
- Real-time Connection Status with NEON Display
- Connection Manager with Profiles
- Professional UI
"""

import sys
import os
from pathlib import Path

from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                              QHBoxLayout, QPushButton, QLabel, QMenuBar,
                              QMenu, QStatusBar, QMessageBox, QToolBar,
                              QDockWidget, QFileDialog, QSplitter)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QKeySequence

# Import our modules
from src.core.connection_manager import ConnectionManager, ConnectionProfile, ConnectionStatus
from src.core.mount_manager import UniversalMountManager
from src.ui.status_widget import NeonStatusWidget, CompactStatusWidget
from src.ui.connection_dialog import ConnectionManagerDialog
from src.protocols.sftp_handler import SFTPHandler, FTPHandler
from src.protocols.smb_handler import SMBHandler
from src.protocols.webdav_handler import WebDAVHandler
from src.utils.logger import get_logger


class MacCommanderProProfessional(QMainWindow):
    """
    MacCommander Pro PROFESSIONAL Edition
    The ULTIMATE file manager for macOS
    """
    
    def __init__(self):
        super().__init__()
        
        # Logger initialisieren ZUERST!
        self.logger = get_logger()
        self.logger.info("Initialisiere MacCommander Pro PROFESSIONAL")
        
        # Core managers
        self.connection_manager = ConnectionManager()
        self.mount_manager = UniversalMountManager()
        
        # Protocol handlers
        self.sftp_handler = SFTPHandler()
        self.ftp_handler = FTPHandler()
        self.smb_handler = SMBHandler()
        self.webdav_handler = WebDAVHandler()
        
        # UI setup
        self.setWindowTitle("MacCommander Pro PROFESSIONAL")
        self.setMinimumSize(1200, 800)
        
        try:
            self._setup_ui()
            self._setup_menu()
            self._setup_toolbar()
            self._setup_shortcuts()
            self._setup_statusbar()
            
            # Load saved profiles
            self._load_profiles()
            
            self.logger.info("MacCommander Pro PROFESSIONAL erfolgreich gestartet!")
            print("🚀 MacCommander Pro PROFESSIONAL started!")
            print("✨ Universal Mount System ready!")
            print("🟢 Connection Manager active!")
        except Exception as e:
            self.logger.critical(f"FEHLER beim Starten: {e}", exc_info=True)
            raise
    
    def _setup_ui(self):
        """Setup main UI"""
        # Central widget with splitter
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Header
        header = self._create_header()
        layout.addWidget(header)
        
        # Main splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Status dock
        self.status_dock = QDockWidget("Connection Status", self)
        self.status_widget = NeonStatusWidget()
        self.status_widget.details_clicked.connect(self._show_connection_details)
        self.status_widget.disconnect_clicked.connect(self._disconnect_current)
        self.status_dock.setWidget(self.status_widget)
        self.status_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable |
            QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.status_dock)
        
        # Quick Actions Panel
        actions_panel = self._create_actions_panel()
        layout.addWidget(actions_panel)
        
        # DUAL-PANE COMMANDER - IN DIE MITTE!
        from src.ui.dual_pane_commander import DualPaneCommander
        self.commander = DualPaneCommander()
        layout.addWidget(self.commander, 1)  # stretch=1 damit es Platz nimmt
    
    def _create_header(self) -> QWidget:
        """Create application header"""
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(10, 10, 10, 10)
        
        # Logo/Title
        title = QLabel("🚀 MacCommander Pro PROFESSIONAL")
        title_font = QFont()
        title_font.setPointSize(18)
        title_font.setBold(True)
        title.setFont(title_font)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        # Compact status
        self.compact_status = CompactStatusWidget()
        self.compact_status.clicked.connect(self._toggle_status_dock)
        header_layout.addWidget(self.compact_status)
        
        return header
    
    def _create_actions_panel(self) -> QWidget:
        """Create quick actions panel"""
        panel = QWidget()
        panel_layout = QHBoxLayout(panel)
        panel_layout.setContentsMargins(10, 10, 10, 10)
        panel_layout.setSpacing(15)
        
        # Connection Manager
        conn_button = QPushButton("📡 Connection Manager")
        conn_button.setMinimumHeight(50)
        conn_button.clicked.connect(self._show_connection_manager)
        panel_layout.addWidget(conn_button)
        
        # Quick Connect
        quick_button = QPushButton("⚡ Quick Connect")
        quick_button.setMinimumHeight(50)
        quick_button.clicked.connect(self._quick_connect)
        panel_layout.addWidget(quick_button)
        
        # Mount
        mount_button = QPushButton("💾 Mount Volume")
        mount_button.setMinimumHeight(50)
        mount_button.clicked.connect(self._mount_dialog)
        panel_layout.addWidget(mount_button)
        
        # Mounted Volumes
        volumes_button = QPushButton("📂 Mounted Volumes")
        volumes_button.setMinimumHeight(50)
        volumes_button.clicked.connect(self._show_mounted_volumes)
        panel_layout.addWidget(volumes_button)
        
        return panel
    
    def _setup_menu(self):
        """Setup menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("&File")
        
        connect_action = QAction("&Connect...", self)
        connect_action.setShortcut(QKeySequence("Ctrl+N"))
        connect_action.triggered.connect(self._show_connection_manager)
        file_menu.addAction(connect_action)
        
        quick_action = QAction("&Quick Connect...", self)
        quick_action.setShortcut(QKeySequence("Ctrl+Q"))
        quick_action.triggered.connect(self._quick_connect)
        file_menu.addAction(quick_action)
        
        file_menu.addSeparator()
        
        mount_action = QAction("&Mount...", self)
        mount_action.setShortcut(QKeySequence("Ctrl+M"))
        mount_action.triggered.connect(self._mount_dialog)
        file_menu.addAction(mount_action)
        
        unmount_action = QAction("&Unmount All", self)
        unmount_action.triggered.connect(self._unmount_all)
        file_menu.addAction(unmount_action)
        
        file_menu.addSeparator()
        
        quit_action = QAction("&Quit", self)
        quit_action.setShortcut(QKeySequence("Ctrl+Q"))
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)
        
        # View menu
        view_menu = menubar.addMenu("&View")
        
        status_action = QAction("Connection &Status", self)
        status_action.setCheckable(True)
        status_action.setChecked(True)
        status_action.triggered.connect(self._toggle_status_dock)
        view_menu.addAction(status_action)
        
        # Help menu
        help_menu = menubar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)
        
        docs_action = QAction("&Documentation", self)
        docs_action.triggered.connect(self._show_docs)
        help_menu.addAction(docs_action)
    
    def _setup_toolbar(self):
        """Setup toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # Quick actions
        toolbar.addAction("📡 Connections", self._show_connection_manager)
        toolbar.addAction("⚡ Quick Connect", self._quick_connect)
        toolbar.addSeparator()
        toolbar.addAction("💾 Mount", self._mount_dialog)
        toolbar.addAction("📂 Volumes", self._show_mounted_volumes)
    
    def _setup_shortcuts(self):
        """Setup keyboard shortcuts"""
        # Ctrl+M for Mount
        # Ctrl+N for New Connection
        # Defined in menu actions
        pass
    
    def _setup_statusbar(self):
        """Setup status bar"""
        statusbar = self.statusBar()
        statusbar.showMessage("Ready | No active connections")
        
        self.statusbar_label = QLabel("Ready")
        statusbar.addPermanentWidget(self.statusbar_label)
    
    def _toggle_status_dock(self):
        """Toggle status dock visibility"""
        self.status_dock.setVisible(not self.status_dock.isVisible())
    
    def _show_connection_manager(self):
        """Show connection manager dialog"""
        self.logger.info("Öffne Connection Manager")
        dialog = ConnectionManagerDialog(self)
        
        # Load profiles
        current_profiles = self._get_profiles_dict()
        dialog.set_profiles(current_profiles)
        self.logger.debug(f"Loaded {len(current_profiles)} profiles into dialog")
        
        # Connect signals
        dialog.connect_requested.connect(self._connect_profile)
        dialog.disconnect_requested.connect(self._disconnect_profile)
        dialog.mount_requested.connect(self._mount_profile)
        
        result = dialog.exec()
        
        # IMMER speichern - auch wenn Cancel!
        try:
            updated_profiles = dialog.get_profiles()
            self._save_profiles(updated_profiles)
            self.logger.info(f"Profile updated: {len(updated_profiles)} profiles")
        except Exception as e:
            self.logger.error(f"Fehler beim Speichern nach Dialog-Schließung: {e}", exc_info=True)
    
    def _quick_connect(self):
        """Quick connect dialog"""
        QMessageBox.information(
            self,
            "Quick Connect",
            "Quick Connect feature - Enter connection details quickly!"
        )
    
    def _mount_dialog(self):
        """Show mount dialog"""
        from PyQt6.QtWidgets import QInputDialog
        
        profiles = self._get_profiles_dict()
        if not profiles:
            QMessageBox.information(
                self,
                "No Profiles",
                "Create a connection profile first in Connection Manager!"
            )
            return
        
        profile_names = list(profiles.keys())
        profile_name, ok = QInputDialog.getItem(
            self,
            "Mount Volume",
            "Select connection to mount:",
            profile_names,
            0,
            False
        )
        
        if ok and profile_name:
            self._mount_profile(profile_name)
    
    def _show_mounted_volumes(self):
        """Show mounted volumes"""
        volumes = self.mount_manager.get_mounted_volumes()
        
        if not volumes:
            QMessageBox.information(
                self,
                "Mounted Volumes",
                "No volumes currently mounted."
            )
            return
        
        volume_list = "\n".join([
            f"• {path} ({info['protocol'].value})"
            for path, info in volumes.items()
        ])
        
        QMessageBox.information(
            self,
            "Mounted Volumes",
            f"Currently mounted volumes:\n\n{volume_list}"
        )
    
    def _connect_profile(self, profile_name: str):
        """Connect using a profile"""
        self.logger.info(f"Verbinde mit Profil: {profile_name}")
        
        try:
            profiles = self._get_profiles_dict()
            profile = profiles.get(profile_name)
            
            if not profile:
                self.logger.error(f"Profil nicht gefunden: {profile_name}")
                QMessageBox.critical(
                    self,
                    "Fehler",
                    f"Profil '{profile_name}' nicht gefunden!"
                )
                return
            
            self.logger.debug(f"Profile details: {profile}")
            
            # Update status
            self.status_widget.set_connecting(profile_name, profile['protocol'])
            self.compact_status.set_status("connecting", f"Connecting to {profile_name}")
            
            # Simulate connection (in production, use actual connection)
            QTimer.singleShot(2000, lambda: self._on_connected(profile_name, profile))
            
        except Exception as e:
            self.logger.error(f"Fehler beim Verbinden mit {profile_name}: {e}", exc_info=True)
            QMessageBox.critical(
                self,
                "Connection Fehler",
                f"Konnte nicht mit {profile_name} verbinden:\n{e}"
            )
    
    def _on_connected(self, name: str, profile: dict):
        """Handle successful connection"""
        self.logger.info(f"Erfolgreich verbunden: {name}")
        
        try:
            self.status_widget.set_connected(name, profile['protocol'], profile['host'])
            self.compact_status.set_status("connected", name)
            self.statusbar_label.setText(f"Connected to {name}")
            
            QMessageBox.information(
                self,
                "Connected",
                f"Successfully connected to {name}!\n\n"
                f"Protocol: {profile['protocol'].upper()}\n"
                f"Host: {profile['host']}\n\n"
                "You can now mount this connection as a volume!"
            )
        except Exception as e:
            self.logger.error(f"Fehler beim Setzen des Connection-Status: {e}", exc_info=True)
    
    def _disconnect_profile(self, profile_name: str):
        """Disconnect a profile"""
        self.logger.info(f"Trenne Verbindung: {profile_name}")
        
        try:
            self.status_widget.set_offline()
            self.compact_status.set_status("offline")
            self.statusbar_label.setText("Disconnected")
            
            QMessageBox.information(self, "Disconnected", f"Disconnected from {profile_name}")
        except Exception as e:
            self.logger.error(f"Fehler beim Trennen: {e}", exc_info=True)
    
    def _disconnect_current(self):
        """Disconnect current connection"""
        self.status_widget.set_offline()
        self.compact_status.set_status("offline")
        self.statusbar_label.setText("Disconnected")
    
    def _mount_profile(self, profile_name: str):
        """Mount a profile as volume"""
        profiles = self._get_profiles_dict()
        profile = profiles.get(profile_name)
        
        if not profile:
            return
        
        protocol = profile['protocol']
        
        # Mount based on protocol
        mount_point = None
        
        if protocol == 'sftp':
            mount_point = self.mount_manager.mount_sftp(
                host=profile['host'],
                username=profile['username'],
                password=profile.get('password', ''),
                ssh_key=profile.get('ssh_key', ''),
                port=profile['port']
            )
        elif protocol == 'ftp':
            mount_point = self.mount_manager.mount_ftp(
                host=profile['host'],
                username=profile['username'],
                password=profile.get('password', ''),
                port=profile['port'],
                use_ssl=profile.get('use_ssl', False)
            )
        elif protocol == 'smb':
            mount_point = self.mount_manager.mount_smb(
                host=profile['host'],
                share=profile.get('share', ''),
                username=profile['username'],
                password=profile.get('password', ''),
                domain=profile.get('domain', '')
            )
        elif protocol == 'webdav':
            url = f"{profile['host']}"
            mount_point = self.mount_manager.mount_webdav(
                url=url,
                username=profile['username'],
                password=profile.get('password', ''),
                use_ssl=profile.get('use_ssl', True)
            )
        
        if mount_point:
            QMessageBox.information(
                self,
                "Mounted!",
                f"Successfully mounted {profile_name}!\n\n"
                f"Mount Point: {mount_point}\n\n"
                "The volume is now available in Finder!"
            )
        else:
            QMessageBox.warning(
                self,
                "Mount Failed",
                f"Failed to mount {profile_name}.\n\n"
                "Check the documentation for required dependencies."
            )
    
    def _unmount_all(self):
        """Unmount all volumes"""
        volumes = self.mount_manager.get_mounted_volumes()
        
        if not volumes:
            QMessageBox.information(self, "Unmount", "No volumes to unmount.")
            return
        
        reply = QMessageBox.question(
            self,
            "Unmount All",
            f"Unmount {len(volumes)} volume(s)?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            for mount_point in list(volumes.keys()):
                self.mount_manager.unmount(mount_point)
            
            QMessageBox.information(self, "Success", "All volumes unmounted!")
    
    def _show_connection_details(self):
        """Show detailed connection info"""
        QMessageBox.information(
            self,
            "Connection Details",
            "Detailed connection information here!"
        )
    
    def _show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self,
            "About MacCommander Pro PROFESSIONAL",
            "<h2>MacCommander Pro PROFESSIONAL</h2>"
            "<p>Version 1.0</p>"
            "<p>The Ultimate Multi-Protocol File Manager for macOS</p>"
            "<h3>Features:</h3>"
            "<ul>"
            "<li>🔗 Multi-Protocol Support (SFTP, FTP, SMB, WebDAV)</li>"
            "<li>💾 Universal Mount System</li>"
            "<li>🟢 Real-time Connection Status</li>"
            "<li>📡 Connection Manager with Profiles</li>"
            "<li>🎨 Professional UI</li>"
            "</ul>"
            "<p><b>© 2025 MacCommander Pro</b></p>"
        )
    
    def _show_docs(self):
        """Show documentation"""
        QMessageBox.information(
            self,
            "Documentation",
            "📚 Documentation\n\n"
            "Check the docs/ folder for:\n"
            "• README.md - Getting started\n"
            "• MOUNT_GUIDE.md - Mounting guide\n"
            "• PROTOCOLS.md - Protocol details\n"
        )
    
    def _load_profiles(self):
        """Load saved connection profiles"""
        import json
        from pathlib import Path
        
        try:
            config_dir = Path.home() / ".maccommander_pro"
            config_dir.mkdir(exist_ok=True)
            profiles_file = config_dir / "profiles.json"
            
            if profiles_file.exists():
                with open(profiles_file, 'r', encoding='utf-8') as f:
                    self.saved_profiles = json.load(f)
                self.logger.info(f"Loaded {len(self.saved_profiles)} profiles")
            else:
                self.saved_profiles = {}
                self.logger.info("No saved profiles found")
        except Exception as e:
            self.logger.error(f"Fehler beim Laden der Profile: {e}", exc_info=True)
            self.saved_profiles = {}
    
    def _save_profiles(self, profiles: dict):
        """Save connection profiles"""
        import json
        from pathlib import Path
        
        try:
            config_dir = Path.home() / ".maccommander_pro"
            config_dir.mkdir(exist_ok=True)
            profiles_file = config_dir / "profiles.json"
            
            self.saved_profiles = profiles
            
            with open(profiles_file, 'w', encoding='utf-8') as f:
                json.dump(profiles, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Saved {len(profiles)} profiles to {profiles_file}")
            print(f"✅ {len(profiles)} Profile gespeichert!")
        except Exception as e:
            self.logger.error(f"Fehler beim Speichern der Profile: {e}", exc_info=True)
            QMessageBox.critical(
                self,
                "Fehler",
                f"Profile konnten nicht gespeichert werden:\n{e}"
            )
    
    def _get_profiles_dict(self) -> dict:
        """Get profiles as dictionary"""
        if not hasattr(self, 'saved_profiles'):
            self.saved_profiles = {}
        return self.saved_profiles
    
    def closeEvent(self, event):
        """Handle application close"""
        # Disconnect all
        for connection in self.connection_manager.list_connections():
            self.connection_manager.disconnect(connection.profile.name)
        
        # Unmount all
        volumes = self.mount_manager.get_mounted_volumes()
        for mount_point in volumes:
            self.mount_manager.unmount(mount_point)
        
        event.accept()


def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    app.setApplicationName("MacCommander Pro PROFESSIONAL")
    app.setOrganizationName("MacCommanderPro")
    
    # Apply dark theme (optional)
    app.setStyle("Fusion")
    
    window = MacCommanderProProfessional()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
