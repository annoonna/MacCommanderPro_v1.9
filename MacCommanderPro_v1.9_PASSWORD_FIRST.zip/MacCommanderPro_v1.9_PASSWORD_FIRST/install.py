#!/usr/bin/env python3
"""
MacCommander Pro PROFESSIONAL - Installation Script
Automatically installs all dependencies
"""

import sys
import subprocess
import os
from pathlib import Path


def print_header():
    """Print installation header"""
    print("=" * 70)
    print("🚀 MacCommander Pro PROFESSIONAL - Installation")
    print("=" * 70)
    print()


def check_python():
    """Check Python version"""
    print("🔍 Checking Python version...")
    
    version = sys.version_info
    if version < (3, 8):
        print(f"❌ Python 3.8+ required! You have {version.major}.{version.minor}")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro}")
    return True


def install_python_packages():
    """Install Python packages"""
    print("\n📦 Installing Python packages...")
    
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
            check=True
        )
        print("✅ Python packages installed!")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to install Python packages")
        return False


def check_homebrew():
    """Check if Homebrew is installed"""
    print("\n🍺 Checking Homebrew...")
    
    try:
        result = subprocess.run(
            ["which", "brew"],
            capture_output=True,
            check=True
        )
        print("✅ Homebrew installed")
        return True
    except subprocess.CalledProcessError:
        print("⚠️  Homebrew not found")
        print("   Install from: https://brew.sh")
        print("   Run: /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
        return False


def install_homebrew_packages():
    """Install Homebrew packages"""
    print("\n🔧 Installing system dependencies...")
    
    packages = [
        "macfuse",      # For FUSE filesystems
        "gromgit/fuse/sshfs-mac",  # For SFTP mounting
    ]
    
    for package in packages:
        print(f"   Installing {package}...")
        try:
            subprocess.run(
                ["brew", "install", package],
                capture_output=True,
                timeout=300
            )
            print(f"   ✅ {package}")
        except Exception as e:
            print(f"   ⚠️  {package} - {e}")
    
    print("✅ System dependencies installed!")
    return True


def create_config_dir():
    """Create configuration directory"""
    print("\n📁 Creating configuration directory...")
    
    config_dir = Path.home() / ".maccommander_pro"
    config_dir.mkdir(exist_ok=True)
    
    print(f"✅ Config directory: {config_dir}")
    return True


def print_summary():
    """Print installation summary"""
    print("\n" + "=" * 70)
    print("✨ Installation Complete!")
    print("=" * 70)
    print()
    print("🚀 To start MacCommander Pro PROFESSIONAL:")
    print("   python3 maccommander_pro.py")
    print()
    print("📚 Documentation:")
    print("   • README.md - Getting started")
    print("   • docs/MOUNT_GUIDE.md - Mount guide")
    print("   • docs/PROTOCOLS.md - Protocol details")
    print()
    print("💡 Tips:")
    print("   • Use Ctrl+N for Connection Manager")
    print("   • Use Ctrl+M for quick mount")
    print("   • Check status dock for live connection info")
    print()
    print("=" * 70)


def main():
    """Main installation function"""
    print_header()
    
    # Check Python
    if not check_python():
        print("\n❌ Installation failed: Python version too old")
        return 1
    
    # Install Python packages
    if not install_python_packages():
        print("\n⚠️  Some Python packages failed to install")
        print("   Try manually: pip3 install -r requirements.txt")
    
    # Check Homebrew
    has_brew = check_homebrew()
    
    if has_brew:
        print("\n💡 Optional: Install system dependencies for full functionality")
        response = input("   Install sshfs-mac and macfuse? (y/n): ").lower()
        
        if response == 'y':
            install_homebrew_packages()
        else:
            print("   Skipped system dependencies")
            print("   Note: SFTP mounting may not work without sshfs-mac")
    
    # Create config directory
    create_config_dir()
    
    # Summary
    print_summary()
    
    return 0


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  Installation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Installation error: {e}")
        sys.exit(1)
